%% =======================  Description  ==================================
% This files prints the plot of Fig. 3 in the paper for acceptance ratio
% with respect to MSE target values in [0.01, 0.1] for Iterative,
% Low-complexity, and SDP-based methods in fully-connected and
% partially-connected structures.

%% ==========================System Parameters==============================
clear
clc
cvx_quiet true

N_t = 20; % input('Number of Transmitter Antennas: ');
N_r = 8; % input('Number of Receiver Antennas: ');
N_cl = 3; % input('Number of Channel Clusters: ');
N_s = 2; % input('Number of Data Streams: ');
N_RFt = 2; % input('Number of RF Chains at Transmitter: ');
N_RFr = 2; % input('Number of RF Chains at Receiver: ');
U = 1; % input('Number of Users: ');


%% ========================== Initialization ==============================

structure_flag = 1; % Structure Flag (FCS = 1 and PCS =0)

N_it = 10;

delta_max_range =  [0.463, 1.034];
delta_max_eff_fcs = [0.113, 0.258];
delta_max_eff_pcs = [0.0864, 0.2020];


QoS_range = 0.01:0.01:0.1;

AR_sdp = zeros(length(QoS_range),length(delta_max_range));
AR_it_fcs = zeros(length(QoS_range),length(delta_max_range));
AR_lc_fcs = zeros(length(QoS_range),length(delta_max_range));
AR_it_pcs = zeros(length(QoS_range),length(delta_max_range));
AR_lc_pcs = zeros(length(QoS_range),length(delta_max_range));


H = zeros(N_r,N_t,U,N_it);
for u = 1:U
    for k = 1:N_it
        [H(:,:,u,k), ~] = channel_generation_ULA(N_t, N_r, N_cl);
    end
end

weight = 1e-3;
num_delta_max = length(delta_max_range);
num_QoS = length(QoS_range);

parpool('local', 10)
for s = 1 : num_delta_max

    delta_max = delta_max_range(s);
    disp('delta_max:')
    disp(delta_max)
    for r = 1 : num_QoS
        
        QoS = QoS_range(r);
        disp('QoS:')
        disp(QoS)
        AR_temp_sdp = zeros(N_it,1);
        AR_temp_it_fcs = zeros(N_it,1);
        AR_temp_lc_fcs = zeros(N_it,1);
        AR_temp_it_pcs = zeros(N_it,1);
        AR_temp_lc_pcs = zeros(N_it,1);
        parfor k = 1 : N_it
            
            disp('Channel Number')
            disp(k)

            [Flag_sdp] = fun_sdp_feasible(H(:,:,:,k),N_s,QoS,delta_max);
            if Flag_sdp == 0
                AR_temp_sdp(k,1) = 0;
            elseif Flag_sdp == 1
                AR_temp_sdp(k,1) = N_s;
            end
            

            [~,~,~,~,~,~,N_ds_it] = ...
                fun_iterative(H(:,:,:,k),N_s,N_RFr,N_RFt,structure_flag,QoS,delta_max_eff_fcs(s),weight);
            AR_temp_it_fcs(k,1) = sum(N_ds_it);
         
            [~,~,~,~,~,N_ds_lc] =...
                fun_low_complexity(H(:,:,:,k),N_s,N_RFr,N_RFt,structure_flag,QoS,delta_max_eff_fcs(s));
            AR_temp_lc_fcs(k,1) = sum(N_ds_lc);

            [flag_it,CUT,F_BB_it,F_RF_it,W_BB_it,W_RF_it,N_ds_it] = ...
                fun_iterative(H(:,:,:,k),N_s,N_RFr,N_RFt,structure_flag - 1,QoS,delta_max_eff_pcs(s),weight);
            AR_temp_it_pcs(k,1) = sum(N_ds_it);

             [flag_lc,F_BB_lc,F_RF_lc,W_BB_lc,W_RF_lc,N_ds_lc] =...
                fun_low_complexity(H(:,:,:,k),N_s,N_RFr,N_RFt,structure_flag - 1,QoS,delta_max_eff_pcs(s));
            AR_temp_lc_pcs(k,1) = sum(N_ds_lc);
        end
        

        AR_sdp(r,s) = sum(AR_temp_sdp)/(N_it*N_s);
        AR_it_fcs(r,s) = sum(AR_temp_it_fcs)/(N_it*N_s);
        AR_lc_fcs(r,s) = sum(AR_temp_lc_fcs)/(N_it*N_s);
        
        AR_it_pcs(r,s) = sum(AR_temp_it_pcs)/(N_it*N_s);
        AR_lc_pcs(r,s) = sum(AR_temp_lc_pcs)/(N_it*N_s);
        % save('AR_sdp','AR_sdp')
        % 
        % save('AR_it_fcs','AR_it_fcs')
        % save('AR_lc_fcs','AR_lc_fcs')
        % 
        % save('AR_it_pcs','AR_it_pcs')
        % save('AR_lc_pcs','AR_lc_pcs')

    end
end

figure
hold on
grid on
plot(QoS_range, smooth(AR_lc_fcs(:, 1)), 'LineWidth', 2, 'Color', 'green', 'LineStyle','-', 'Marker','square', 'MarkerSize',8)
plot(QoS_range, smooth(AR_it_fcs(:, 1)), 'LineWidth', 2,  'Color', 'blue', 'LineStyle','-', 'Marker','o', 'MarkerSize',8)
plot(QoS_range, smooth(AR_lc_fcs(:, 2)), 'LineWidth', 2,  'Color', 'green', 'LineStyle','--', 'Marker','square', 'MarkerSize',8)
plot(QoS_range, smooth(AR_it_fcs(:, 2)), 'LineWidth', 2,  'Color', 'blue', 'LineStyle','--', 'Marker','o', 'MarkerSize',8)
plot(QoS_range, smooth(AR_sdp(:, 1)),   'LineWidth', 2,  'Color', 'red', 'LineStyle','-', 'Marker','+', 'MarkerSize',8)
plot(QoS_range, smooth(AR_lc_pcs(:, 1)),'LineWidth', 2,  'Color', 'green', 'LineStyle','-', 'Marker','^', 'MarkerSize',8)
plot(QoS_range, smooth(AR_it_pcs(:, 1)),'LineWidth', 2,  'Color', 'blue', 'LineStyle','-', 'Marker','v', 'MarkerSize',8)
plot(QoS_range, smooth(AR_lc_pcs(:, 2)),'LineWidth', 2,  'Color', 'green', 'LineStyle','--', 'Marker','^', 'MarkerSize',8)
plot(QoS_range, smooth(AR_it_pcs(:, 2)),'LineWidth', 2,  'Color', 'blue', 'LineStyle','--', 'Marker','v', 'MarkerSize',8)
plot(QoS_range, smooth(AR_sdp(:, 2)),   'LineWidth', 2,  'Color', 'red', 'LineStyle','--', 'Marker','+', 'MarkerSize',8)

legend({'LC (FCS), \epsilon_{eff} = 0.11',...
    'It (FCS), \epsilon_{eff} = 0.11',...
    'LC (FCS), \epsilon_{eff} = 0.26',...
    'It (FCS), \epsilon_{eff} = 0.26',...
    'SDP, \epsilon = 0.46',...
    'LC (PCS), \epsilon_{eff} = 0.09',...
    'It (PCS), \epsilon_{eff} = 0.09',...
    'LC (PCS), \epsilon_{eff} = 0.20',...
    'It (PCS), \epsilon_{eff} = 0.20',...
    'SDP, \epsilon = 1.03'}, 'fontsize', 10, 'interpreter', 'tex')

xlabel('\rho','fontsize',14, 'interpreter', 'tex')
ylabel('Acceptance Ratio','fontsize',14, 'FontName', 'Times New Roman')