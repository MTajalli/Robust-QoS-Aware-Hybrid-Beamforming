function [Flag] = fun_sdp_feasible(H, N_s, QoS, delta_max)

cvx_quiet true
% ==========================System Parameters==============================
Flag = 0;
[N_r,~,U,~] = size(H);

mu = QoS*ones(N_s,U);

F = zeros(N_r,N_s,U);
for u = 1:U
    [Uh,~,~] = svd(H(:,:,u));
    F(:,:,u) = Uh(:,1:N_s);
end

[~, ~, ~, ~, cvx_status] = fd_precoder(H, F, mu, delta_max);
if strcmp(cvx_status,'Infeasible') == 1
    Flag = 0;
elseif strcmp(cvx_status,'Solved') == 1
    Flag = 1;
end
end