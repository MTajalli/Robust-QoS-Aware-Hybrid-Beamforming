function [F_RFBD,F_BB, W_RF, W_BB] = non_robust_dft(H,N_s,N_RFr,N_RFt,QoS)

[N_r,N_t,U] = size(H);
sigma = 1;
DFT = dftmtx(N_r);
W_RFBD = zeros(N_r,N_RFr,U);
for u = 1:U
    gain = zeros(N_r,1);
    for j = 1:N_r
        gain(j) = norm(DFT(:,j)'*H(:,:,u),1)^2;
    end
    gain_sort = sort(gain,'descend');
    receiver_index = zeros(N_RFr,1);
    for j = 1:N_RFr
        receiver_index(j) = find(gain_sort(j)==gain);
    end
    W_RFBD(:,:,u) = DFT(:,receiver_index);
end
H_int = zeros(U*N_RFr,N_t);
for u = 1:U
    H_int((u-1)*N_RFr+1:u*N_RFr,:) = W_RFBD(:,:,u)'*H(:,:,u);
end
F_RFBD = exp(1i*angle(H_int'));
Heff = zeros(N_RFr,N_RFt,U);
Heff_u = zeros((U-1)*N_RFr,N_RFt,U);
for u = 1:U
    Heff(:,:,u) = W_RFBD(:,:,u)'*H(:,:,u)*F_RFBD;
end
V_0 = zeros(N_RFt,N_RFt-(U-1)*N_RFr,U);
F_HBD = zeros(N_RFt,N_s,U);
sum_power_hbd = 0;
W_HBD = zeros(N_RFr,N_s,U);
for u = 1:U
    for uu = setdiff(1:U,u)
        Heff_u((uu-1)*N_RFr+1:uu*N_RFr,:,u) = Heff(:,:,uu);
    end
    R_nu = sigma^2*W_RFBD(:,:,u)'*W_RFBD(:,:,u);
    [~,~,V_intu] = svd(Heff_u(:,:,u));
    V_0(:,:,u) = V_intu(:,(U-1)*N_RFr+1:N_RFt);
    [~,S_u,V_u] = svd(sqrtm(inv(R_nu))*Heff(:,:,u)*V_0(:,:,u));
    rho = QoS*ones(N_s,1);
    p_hbd = 1./diag(S_u(1:N_s,1:N_s).^2).*(1./rho-1);
    F_HBD(:,:,u) = V_0(:,:,u)*V_u(:,1:N_s)*sqrtm(diag(p_hbd));
    F_AD = F_RFBD*F_HBD(:,:,u);
    sum_power_hbd = sum_power_hbd + trace(F_AD'*F_AD);
    W_HBD(:,:,u)=inv(Heff(:,:,u)*F_HBD(:,:,u)*F_HBD(:,:,u)'*Heff(:,:,u)'+R_nu)*Heff(:,:,u)*F_HBD(:,:,u);

end
F_BB = zeros(N_RFt,U*N_s);
W_BB = cell(1,U);
W_RF = cell(1,U);
for u = 1:U
    F_BB(:,(u-1)*N_s+1:u*N_s) = F_HBD(:,:,u);
    W_BB{1,u} = W_HBD(:,:,u);
    W_RF{1,u} = W_RFBD(:,:,u);
end
end