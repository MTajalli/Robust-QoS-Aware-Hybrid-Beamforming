function [H,AT] = channel_generation(N_t,N_r,N_cl)
Nt_h = sqrt(N_t);
Nt_v = sqrt(N_t);
Nr_h = sqrt(N_r);
Nr_v = sqrt(N_r);
AS = 10;
N_ray = 10;
D = 0.5;
N_it = 1;
L = N_cl*N_ray;
angle_spread = (AS/180)*pi;
alpha = zeros(L,N_it);
phi_t = zeros(L,N_it);
phi_r = zeros(L,N_it);
theta_t = zeros(L,N_it);
theta_r = zeros(L,N_it);
AT_h = zeros(Nt_h,L,N_it);
AT_v = zeros(Nt_v,L,N_it);
AR_h = zeros(Nr_h,L,N_it);
AR_v = zeros(Nr_v,L,N_it);
AT = zeros(N_t,L,N_it);
AR = zeros(N_r,L,N_it);
CH = zeros(N_r,N_t,L);
H = zeros(N_r,N_t);
% ================== Generating the Clustered Channel======================

for k = 1:N_it
    H1 = zeros(N_r,N_t);
    for ll = 1:N_cl
        phi_mean_t = -pi + 2*pi*rand;
        phi_mean_r = -pi + 2*pi*rand;
        theta_mean_t = -pi/2 + pi*rand;
        theta_mean_r = -pi/2 + pi*rand;
        for l = (ll-1)*N_ray+1:ll*N_ray
            alpha(l,k) = (randn+1i*randn)/sqrt(2);
            phi_t(l,k) = laprand(phi_mean_t,angle_spread);
            phi_r(l,k) = laprand(phi_mean_r,angle_spread);
            theta_t(l,k) = laprand(theta_mean_t,angle_spread);
            theta_r(l,k) = laprand(theta_mean_r,angle_spread);
            for n = 1:Nt_h
                AT_h(n,l,k) = exp(1i*2*pi*D*(n-1)*sin(theta_t(l,k))*cos(phi_t(l,k)))/sqrt(Nt_h);
            end
            for n = 1:Nt_v
                AT_v(n,l,k) = exp(1i*2*pi*D*(n-1)*cos(theta_t(l,k)))/sqrt(Nt_v);
            end
            for n = 1:Nr_h
                AR_h(n,l,k) = exp(1i*2*pi*D*(n-1)*sin(theta_r(l,k))*cos(phi_r(l,k)))/sqrt(Nr_h);
            end
            for n = 1:Nr_v
                AR_v(n,l,k) = exp(1i*2*pi*D*(n-1)*cos(theta_r(l,k)))/sqrt(Nr_v);
            end
            AT(:,l,k) = kron(AT_h(:,l,k),AT_v(:,l,k));
            AR(:,l,k) = kron(AR_h(:,l,k),AR_v(:,l,k));
            CH(:,:,l) = alpha(l,k)*AR(:,l,k)*AT(:,l,k)';
            H1 = H1+CH(:,:,l);
        end
    end
    H = H1;
end
H = sqrt(N_t*N_r/L)*H;
end