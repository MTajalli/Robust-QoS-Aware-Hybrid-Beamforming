%% =======================  Description  ==================================
% This files prints the plot of Fig. 7 in the paper for CDF of achieved MESs
% with respect to MSE target 0.2 for Iterative and Low-complexity methods
% as well as three state-of-the art methods in presented in Refs [5], [6],
% and [8].

% ==========================System Parameters==============================
clear
clc
cvx_quiet true

N_t = 64; % input('Number of Horizontal Transmitter Antennas: ');
N_r = 16; % input('Number of Horizontal Receiver Antennas: ');
N_s = 2; % input('Number of Data Streams: ');
N_RFt = 4; % input('Number of RF Chains at Transmitter: ');
N_RFr = 2; % input('Number of RF Chains at Receiver: ');
U = 2; % input('Number of Users: ');

N_test = 1e2;
N_cl = 3;
structure_flag = 1; % (FCS = 1 and PCS =0)
N_it = 1;
delta_max_range = [0, 1.6766, 3.3572];
% delta_max_eff = [.113,.258];
delta_max_eff = [0.1941 0.4472];
% delta_max_eff = 0.4472;

num_delta = length(delta_max_eff);

QoS = 0.2;
rho = QoS*ones(N_s,1);
sigma_n = 1;

sigma_e = 0 : 0.01 : 1;
axis = QoS - 0.05 : .001 : QoS + 0.01;

CDF_it = zeros(length(axis),length(delta_max_eff));
CDF_lc = zeros(length(axis),length(delta_max_eff));

CDF_it_square = zeros(length(axis),length(delta_max_eff));
CDF_lc_square = zeros(length(axis),length(delta_max_eff));


H = zeros(N_r,N_t,U);
for u = 1:U
    [H(:,:,u), ~] = channel_generation(N_t, N_r, N_cl);
end

[F_RF_one, F_BB_one, W_RF_one, W_BB_one] = non_robust_one(H,N_s,N_RFr,N_RFt,QoS);
[F_RF_dft, F_BB_dft, W_RF_dft, W_BB_dft] = non_robust_dft(H,N_s,N_RFr,N_RFt,QoS);
[F_RF_arab,F_BB,W_RF,W_BB] = arab(H,N_RFt,N_RFr,N_s,rho);

Rn_one = cell(1,U);
Rn_dft = cell(1,U);
Rn_arab = cell(1,U);

W_RF_arab = cell(1,U);
W_BB_arab = cell(1,U);
F_BB_arab = zeros(N_RFt,U*N_s);

N_ds = N_s*ones(1,U);

for u = 1:U
    W_BB_arab{1,u} = W_BB(:,:,u);
    W_RF_arab{1,u} = W_RF(:,:,u);
    F_BB_arab(:,(u-1)*N_s + 1 : u*N_s) = F_BB(:,:,u);
    Rn_one{1,u} = sigma_n^2*W_RF_one{1,u}'*W_RF_one{1,u};
    Rn_dft{1,u} = sigma_n^2*W_RF_dft{1,u}'*W_RF_dft{1,u};
    Rn_arab{1,u} = sigma_n^2*W_RF_arab{1,u}'*W_RF_arab{1,u};
end

CDF_one = cdf_mu(F_BB_one,F_RF_one,W_BB_one,W_RF_one,Rn_one,H,N_ds,max(delta_max_range),axis,N_test);

CDF_dft = cdf_mu(F_BB_dft,F_RF_dft,W_BB_dft,W_RF_dft,Rn_dft,H,N_ds,max(delta_max_range),axis,N_test);

CDF_arab = cdf_mu(F_BB_arab,F_RF_arab,W_BB_arab,W_RF_arab,Rn_arab,H,N_ds,max(delta_max_range),axis,N_test);

weight = 0.01;

parpool('local', num_delta)

parfor s = 1 : num_delta
    
    delta_max = delta_max_eff(s);
    
    disp('delta_max:')
    disp(delta_max)
    
    [flag_it,CUT,F_BB_it,F_RF_it,W_BB_it,W_RF_it,N_ds_it] = ...
        fun_iterative(H,N_s,N_RFr,N_RFt,structure_flag,QoS,delta_max,weight);
    Rn_it = cell(1,U);
    Rho_it = cell(1,U);
    for u = 1:U
        Rn_it{1,u} = sigma_n^2*W_RF_it{1,u}'*W_RF_it{1,u};
        Rho_it{1,u} = QoS*ones(1,N_ds_it(1,u));
    end
    
    CDF_it(:,s) = cdf_mu(F_BB_it,F_RF_it,W_BB_it,W_RF_it,Rn_it,H,N_ds_it,max(delta_max_range),axis,N_test);
    CDF_it_square(:,s) = cdf_square_mu(F_BB_it,F_RF_it,W_BB_it,W_RF_it,Rn_it,H,N_ds_it,max(delta_max_range),axis,N_test);
    
    [flag_lc,F_BB_lc,F_RF_lc,W_BB_lc,W_RF_lc,N_ds_lc] =...
        fun_low_complexity(H,N_s,N_RFr,N_RFt,structure_flag,QoS,delta_max);
    
    Rn_lc = cell(1,U);
    Rho_lc = cell(1,U);
    for u = 1:U
        Rn_lc{1,u} = sigma_n^2*W_RF_lc{1,u}'*W_RF_lc{1,u};
    end
    
    CDF_lc(:,s) = cdf_mu(F_BB_lc,F_RF_lc,W_BB_lc,W_RF_lc,Rn_lc,H,N_ds_lc,max(delta_max_range),axis,N_test);
    CDF_lc_square(:,s) = cdf_square_mu(F_BB_lc,F_RF_lc,W_BB_lc,W_RF_lc,Rn_lc,H,N_ds_lc,max(delta_max_range),axis,N_test);
    
    % save('CDF_it','CDF_it')
    % save('CDF_lc','CDF_lc')
    % save('CDF_it_square','CDF_it_square')
    % save('CDF_lc_square','CDF_lc_square')
    % save('CDF_one','CDF_one')
    % save('CDF_dft','CDF_dft')
    
end

%% ==============================  Plot =================================== 

figure
hold on
grid on

% plot(axis,smooth(smooth(CDF_it_square(:,1))),'b-diamond' , 'markerindices',1:10:61, 'LineWidth', 2, 'MarkerSize', 8)
% plot(axis,smooth(smooth(CDF_lc_square(:,1))),'g-hexagram','markerindices',1:10:61, 'LineWidth', 2, 'MarkerSize', 8)
% plot(axis,smooth(smooth(CDF_it_square(:,2))),'b--diamond' , 'markerindices',1:10:61, 'LineWidth', 2, 'MarkerSize', 8)
% plot(axis,smooth(smooth(CDF_lc_square(:,2))),'g--hexagram','markerindices',1:10:61, 'LineWidth', 2, 'MarkerSize', 8)

plot(axis,smooth(smooth(CDF_it(:,2))),'b--o','markerindices',1:10:61, 'LineWidth', 2, 'MarkerSize', 8)
plot(axis,smooth(smooth(CDF_lc(:,2))),'g--s','markerindices',1:10:61, 'LineWidth', 2, 'MarkerSize', 8)
plot(axis,smooth(smooth(CDF_it(:,1))),'b-o','markerindices',1:10:61, 'LineWidth', 2, 'MarkerSize', 8)
plot(axis,smooth(smooth(CDF_lc(:,1))),'g-s','markerindices',1:10:61, 'LineWidth', 2, 'MarkerSize', 8)
plot(axis,CDF_one,'-*', 'color', [0.93,0.69,0.13], 'markerindices',1:10:61, 'LineWidth', 2, 'MarkerSize', 10)
plot(axis,CDF_dft,'r-+','markerindices',1:10:61, 'LineWidth', 2, 'MarkerSize', 8)
plot(axis,CDF_arab,'m-pentagram', 'Color', [1.00,0.00,1.00] ,'markerindices',1:10:61, 'LineWidth', 2, 'MarkerSize', 8)

% legend('It, Hypercube, $\epsilon_{\rm eff} = 0.194$','LC, Hypercube, $\epsilon_{\rm eff} = 0.194$','It, Hypercube, $\epsilon_{\rm eff} = 0.447$',...
%     'LC, Hypercube, $\epsilon_{\rm eff} = 0.447$','It, $\epsilon_{\rm eff} = 0.447$',...
%     'LC, $\epsilon_{\rm eff} = 0.447$', 'It, $\epsilon_{\rm eff} = 0.194$', 'LC, $\epsilon_{\rm eff} = 0.194$',...
% 'Non-robust [6]','Non-robust [5]', 'ARAB', 'fontsize',9, 'Interpreter', 'latex')
    
legend('It, $\epsilon_{\rm eff} = 0.447$','LC, $\epsilon_{\rm eff} = 0.447$',...
    'It, $\epsilon_{\rm eff} = 0.194$', 'LC, $\epsilon_{\rm eff} = 0.194$',...
'Non-robust [6]','Non-robust [5]', 'ARAB', 'fontsize',9, 'Interpreter', 'latex')


xlabel('$r$','fontsize',14, 'Interpreter','latex')
ylabel('CDF','fontsize',14, 'FontName', 'Times New Roman')