function Delta_eff = worst_case_mu(H_eff,F_BB,W_BB,N_ds,delta_max_eff,counter)
% This function returns the worst-case channels for all data streams
% of user u
[N_s, Dim] = size(H_eff);
U = Dim/N_s;
Delta_eff = zeros(N_s,U*N_s,N_ds);
for k = 1:N_ds
    X = zeros(U*N_s^2+1,U*N_s^2+1);
    A = kron(conj(F_BB)*F_BB.',W_BB(:,k)*W_BB(:,k)');
    x = F_BB*F_BB'*H_eff'*W_BB(:,k)-F_BB(:,counter + k);
    b = kron(x.',W_BB(:,k)')';
    cvx_begin sdp quiet
        cvx_solver mosek
        variable gamma1
        variable lambda
        expression X(U*N_s^2+1,U*N_s^2+1)
        X(1:U*N_s^2,1:U*N_s^2) = -A+lambda*eye(U*N_s^2);
        X(1:U*N_s^2,U*N_s^2+1) = -b;
        X(U*N_s^2+1,1:U*N_s^2) = -b';
        X(U*N_s^2+1,U*N_s^2+1) = -lambda*delta_max_eff - gamma1;
        X = 0.5 * ( X + X' );
        maximize gamma1
        subject to
            X >= 0;
            lambda >= 0;
    cvx_end
    delta_eff = -pinv(A-lambda*eye(U*N_s^2))*b;
    for kk = 1 : U*N_s
        Delta_eff(:, kk, k) = delta_eff((kk - 1)*N_s + 1 : kk*N_s).';
    end
end
end