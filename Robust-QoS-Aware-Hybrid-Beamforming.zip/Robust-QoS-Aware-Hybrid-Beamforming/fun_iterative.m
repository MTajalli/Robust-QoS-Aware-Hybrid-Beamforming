function [Feasibility_flag,CUT,F_BB,F_RF,W_BB,W_RF,N_ds] = ...
    fun_iterative(H,N_s,N_RFr,N_RFt,structure_flag,QoS,delta_max_eff,weight)

% ==========================System Parameters==============================

[~,~,U,~] = size(H);
rho = QoS*ones(N_s,U);
Rho = cell(1,U);
N_ds = N_s*ones(1,U);
for u = 1:U
    Rho{1,u} = rho(:,u);
end
sigma_n = 1;
N_cut = 100;

% =========================Channel Generation =============================


H_sampled = cell(N_s,U,N_cut);

% ========================Feasibility Analysis=============================

CUT = zeros(N_cut,1);
q = 0; % Counter of Cutting-Set Method
while true % Cutting-Set Method Loop
    q = q+1;

    while true % Elasticization Loop
        if q == 1
            if structure_flag == 1
                [F_RF,W_RF] = analog_beamforming_mu(H,N_RFt,N_RFr,N_ds); % F_RF: (N_t,sum(N_ds)), W_RF: cell(1,U)
            else
                [F_RF,W_RF] = analog_beamforming_mu_pcs(H,N_RFt,N_RFr,N_ds);
            end
            %             else
            F_RF = F_RF(:,1:sum(N_ds));
            for u = 1:U
                W_temp = W_RF{1,u};
                W_RF{1,u} = W_temp(:,1:N_ds(1,u));
            end
            %             end
            H_eff = cell(1,U);
            R_n = cell(1,U);
            for u = 1:U
                R_n{1,u} = sigma_n^2*(W_RF{1,u})'*W_RF{1,u};
                H_eff{1,u} = W_RF{1,u}'*H(:,:,u)*F_RF;
            end
            for u = 1:U
                for k = 1:N_ds(1,u)
                    H_sampled{k,u,1} = H_eff{1,u};
                end
            end
        end
        %         disp('Solving Sampled Problem...')
        [F_BB,W_BB,elastic] = sampled_mu(H_sampled,R_n,Rho,N_ds,q,weight);
        max_index = zeros(1,U);
        max_value = zeros(1,U);
        for u = 1:U
            [max_value(1,u),max_index(1,u)] = max(elastic{1,u});
        end
        [elastic_max , u_max] = max(max_value);
        if elastic_max >= 0.0001
            k_max = max_index(u_max);
            Rho_temp = Rho{1,u_max};
            Rho_temp(k_max) = [];
            Rho{1,u_max} = Rho_temp;
            N_ds(1,u_max) = N_ds(1,u_max) - 1;
            q = 1;
        else
            break
        end
        for u = 1:U
            if isempty(Rho{1,u}) == 1
                U = U - 1;
                N_ds(:,u) = [];
                Rho(:,u) = [];
                H(:,:,u) = [];
                H_sampled(:,u,:) = [];
                break
            end
        end
        if U == 0
            break
        end
    end
    if U == 0
        break
    end

    Delta_eff = cell(1,U);
    counter = 0;
    for u = 1:U
        Delta_eff{1,u} = worst_case_mu(H_eff{1,u},F_BB,W_BB{1,u},N_ds(1,u),delta_max_eff,counter);
        counter = counter + N_ds(1,u);
    end
    
    inf = 0;
    Tol = 0;
    counter = 0;
    for u = 1:U
        D_eff = Delta_eff{1,u};
        Rho_temp = Rho{1,u};
        for k = 1:N_ds(1,u)
            H_error = H_eff{1,u} + D_eff(:,:,k);
            MSE = ( W_BB{1,u}'*H_error*F_BB )*( W_BB{1,u}'*H_error*F_BB)'...
                -2*real(W_BB{1,u}'*H_error*F_BB(:,counter+1:counter+N_ds(1,u)))...
                + (W_BB{1,u})'*R_n{1,u}*W_BB{1,u} + eye(N_ds(1,u));
            if MSE(k,k) >= Rho_temp(k,1) + .001
                Tol = Tol + MSE(k,k) - Rho_temp(k,1);
                inf = inf + 1;
                H_sampled{k,u,q+1} = H_error;
            else
                H_sampled{k,u,q+1} = H_eff{1,u};
            end
        end
        counter = counter + N_ds(1,u);
    end
    CUT(q,1) = abs(Tol);
    if  q >= 5
        break
    end
end
CUT = CUT(1:q);
if U == 0
    Feasibility_flag = 0;
else
    Feasibility_flag = 1;
end
end

