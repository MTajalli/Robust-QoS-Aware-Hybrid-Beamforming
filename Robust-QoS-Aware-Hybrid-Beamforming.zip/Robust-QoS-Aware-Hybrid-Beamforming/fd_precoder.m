function [P_new, G, lambda, p, cvx_status] = fd_precoder(H,F,mu,epsilon)

[~,N_s,~] = size(F);
[N_r,N_t,U,~] = size(H);
Q = zeros(N_s,U*N_s,U);
for u = 1:U
    Q(:,(u-1)*N_s+1:u*N_s,u) = eye(N_s);
end
psi = zeros(U*N_s,N_s,U);
Psi = zeros(U*N_s,N_t*N_r,N_s,U);
X = zeros(2+U*N_s+N_t*N_r,2+U*N_s+N_t*N_r,N_s,U);

    cvx_begin sdp
        cvx_solver mosek
        variable G_var(N_t, U*N_s) complex
        variable lambda(N_s,U)
        variable p(N_s,U)
        expression psi(U*N_s,N_s,U)
        expression Psi(U*N_s,N_t*N_r,N_s,U)
        expression X(2+U*N_s+N_t*N_r,2+U*N_s+N_t*N_r,N_s,U)
        for u = 1:U
            for n = 1:N_s
                psi(:,n,u) = (F(:,n,u)'*H(:,:,u)*G_var - p(n,u)*Q(n,:,u)).';
                Psi(:,:,n,u) = kron(G_var.',F(:,n,u)');
                X(1,1,n,u) = p(n,u)*sqrt(mu(n,u))-lambda(n,u);
                X(1,2:1+U*N_s,n,u) = psi(:,n,u)';
                X(2:1+U*N_s,1,n,u) = psi(:,n,u);
                X(1,2+U*N_s,n,u) = norm(F(:,n,u));
                X(2+U*N_s,1,n,u) = norm(F(:,n,u));
                X(1,3+U*N_s:2+U*N_s+N_t*N_r,n,u) = zeros(1,N_t*N_r);
                X(3+U*N_s:2+U*N_s+N_t*N_r,1,n,u) = zeros(1,N_t*N_r)';
                X(2:U*N_s+1,2:U*N_s+1,n,u) = p(n,u)*sqrt(mu(n,u))*eye(U*N_s);
                X(2:U*N_s+1,U*N_s+2,n,u) = zeros(U*N_s,1);
                X(U*N_s+2,2:U*N_s+1,n,u) = zeros(U*N_s,1)';
                X(2:U*N_s+1,U*N_s+3:U*N_s+2+N_t*N_r,n,u) = -epsilon*Psi(:,:,n,u);
                X(U*N_s+3:U*N_s+2+N_t*N_r,2:U*N_s+1,n,u) = -epsilon*Psi(:,:,n,u)';
                X(U*N_s+2,U*N_s+2,n,u) = p(n,u)*sqrt(mu(n,u));
                X(U*N_s+2,U*N_s+3:2+U*N_s+N_t*N_r,n,u) = zeros(1,N_t*N_r);
                X(U*N_s+3:2+U*N_s+N_t*N_r,U*N_s+2,n,u) = zeros(1,N_t*N_r)';
                X(U*N_s+3:2+U*N_s+N_t*N_r,U*N_s+3:2+U*N_s+N_t*N_r,n,u) = lambda(n,u)*eye(N_t*N_r);
            end
            X(:,:,n,u) = 0.5*( X(:,:,n,u) + X(:,:,n,u)' );
        end

        minimize quad_form( G_var(:), eye(N_t*U*N_s) )
        subject to
        for u = 1:U
            for n = 1:N_s
                X(:,:,n,u) >= 0;
            end
        end
    cvx_end
G = G_var;
P_new = norm(G_var,'fro')^2;