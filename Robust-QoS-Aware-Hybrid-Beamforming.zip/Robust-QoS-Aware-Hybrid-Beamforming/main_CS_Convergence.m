%% =======================  Description  ==================================
% This files prints the plot of Fig. 10 in the paper for MSE violation in
% various iterations of the cutting-set method in several uncertainty set sizes.


%% ==========================System Parameters=============================
clear
clc
cvx_quiet true

N_t = 128; % input('Number of Horizontal Transmitter Antennas: ');
N_r = 36; % input('Number of Horizontal Receiver Antennas: ');
N_s = 3; % input('Number of Data Streams: ');
N_RFr = 3; % input('Number of RF Chains at Receiver: ');
U = 3; % input('Number of Users: ');
N_RFt = 9; % input('Number of RF Chains at Transmitter: ');

N_it = 1;
delta_max_eff = [0.1, 0.5, 1];
QoS = 0.1;
structure_flag = 1;
 H = sqrt(1/2)*(randn(N_r,N_t,U,N_it)+1i*randn(N_r,N_t,U,N_it));
% load('H_MU');

weight = 10^-1;
CUT_it = zeros(5,N_it);
CUT = zeros(length(delta_max_eff),5);
% parpool('local', 10)

for s = 1:length(delta_max_eff)
    disp('delta_max_eff')
    disp(delta_max_eff(s))
    for k = 1:N_it
        disp('Channel Number')
        disp(k)
        
        [flag_it,CUT_it(:,k),F_BB_it,F_RF_it,W_BB_it,W_RF_it,N_ds_it] = ...
            fun_iterative(H(:,:,:,k),N_s,N_RFr,N_RFt,structure_flag,QoS,delta_max_eff(s),weight);
    end
    CUT(s,:) = mean(CUT_it, 2);
end


%% =============================  Plot  ===================================

figure
hold on 
grid on
plot(1:5, CUT(3, :), 'LineWidth', 2, 'Color','blue','Marker','o', 'MarkerSize',10)
plot(1:5, CUT(2, :), 'LineWidth', 2, 'Color','blue','Marker','square', 'MarkerSize',10)
plot(1:5, CUT(1, :), 'LineWidth', 2, 'Color','blue','Marker','+', 'MarkerSize',10)

legend('Iterative, $\epsilon_{\rm eff} = 1$', 'Iterative, $\epsilon_{\rm eff} = 0.5$',...
    'Iterative, $\epsilon_{\rm eff} = 0.1$','interpreter', 'latex','fontsize', 14)
xlabel('Iteration', 'Interpreter','latex','fontsize', 14)
ylabel('MSE Violation', 'Interpreter','latex','fontsize', 14)