function [F] = fd_combiner(H, G, epsilon)

[N_r,N_t,U] = size(H);
[~,X] = size(G);
N_s = X/U;
F = zeros(N_r,N_s,U);
Q = zeros(N_s,U*N_s,U);
for u = 1:U
    Q(:,(u-1)*N_s+1:u*N_s,u) = eye(N_s);
end

X = zeros(1+U*N_s+N_t*N_r,1+U*N_s+N_t*N_r);

for u = 1:U
    for n = 1:N_s
    cvx_begin sdp
        variable f(N_r, 1) complex
        variable lambda
        variable tau
        expression psi(U*N_s,1)
        expression Psi(U*N_s,N_t*N_r)
        expression X(1+U*N_s+N_t*N_r,1+U*N_s+N_t*N_r)

                psi = (f'*H(:,:,u)*G - Q(n,:,u)).';
                Psi = kron(G.',f');
                X(1,1) = tau-lambda;
                X(1,2:1+U*N_s) = psi';
                X(2:1+U*N_s,1) = psi;
                X(1,2+U*N_s:1+U*N_s+N_t*N_r) = zeros(1,N_t*N_r);
                X(2+U*N_s:1+U*N_s+N_t*N_r,1) = zeros(1,N_t*N_r)';
                X(2:U*N_s+1,2:U*N_s+1) = eye(U*N_s);
                X(2:U*N_s+1,U*N_s+2:U*N_s+1+N_t*N_r) = -epsilon*Psi;
                X(U*N_s+2:U*N_s+1+N_t*N_r,2:U*N_s+1) = -epsilon*Psi';
                X(U*N_s+2:1+U*N_s+N_t*N_r,U*N_s+2:1+U*N_s+N_t*N_r) = lambda*eye(N_t*N_r);
                X = 0.5*( X + X' );

        minimize tau+ quad_form(f,eye(N_r))
        subject to
            X >= 0;
         %   lambda >= 0;
         %   tau >= 0;

    cvx_end
%     disp(cvx_status)
    F(:,n,u) = f;
    end
end