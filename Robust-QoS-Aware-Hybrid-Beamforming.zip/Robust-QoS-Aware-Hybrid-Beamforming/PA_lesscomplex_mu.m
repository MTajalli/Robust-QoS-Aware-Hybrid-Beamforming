function [P_robust] = PA_lesscomplex_mu(Rho,beta,S_u,N_ds,delta_max_eff)
[~,U] = size(Rho);
P_robust = cell(1,U);
% ============================ FINDING P_MAX ==============================
P_nom = cell(1,U);
max_index = zeros(1,U);
max_value = zeros(1,U);
for u = 1:U
    P_nom{1,u} = 1./diag(S_u{1,u}).^2.*(1./Rho{1,u}-1);
    [max_value(1,u),max_index(1,u)] = max(P_nom{1,u});
end
[~ , u_max] = max(max_value);
k_max = max_index(1,u_max);
S_temp = diag(S_u{1,u_max});
Rho_temp = Rho{1,u_max};
beta_temp = beta{1,u_max};
a = delta_max_eff^2*beta_temp(k_max,1)^2*S_temp(k_max,1)^2 - Rho_temp(k_max,1)*S_temp(k_max,1)^4;
b = S_temp(k_max,1)^2 + 2*delta_max_eff*beta_temp(k_max,1)*S_temp(k_max,1)...
    - 2*Rho_temp(k_max,1)*S_temp(k_max,1)^2;
c = 1 - Rho_temp(k_max,1);
D_p = b^2 - 4*a*c;
P_temp = zeros(N_ds(1,u_max),1);
p_max = (-b-sqrt(D_p))/(2*a);
P_temp(k_max,1) = p_max;
P_robust{1,u_max} = P_temp;
% =========================  POWER ALLOCATION  ============================
for u = 1:U
    beta_temp = beta{1,u};
    S_temp = diag(S_u{1,u});
    Rho_temp = Rho{1,u};
    P_temp = zeros(N_ds(1,u),1);
    for j = 1:N_ds(1,u)
        a = -Rho_temp(j,1)*S_temp(j,1)^4;
        b = S_temp(j,1)^2+2*delta_max_eff*beta_temp(j,1)*S_temp(j,1)...
            -2*Rho_temp(j,1)*S_temp(j,1)^2+delta_max_eff^2*beta_temp(j,1)^2*S_temp(j,1)^2*p_max;
        c = 1-Rho_temp(j,1);
        D_p = b^2-4*a*c;
        P_temp(j,1) = (-b-sqrt(D_p))/(2*a);
        if u == u_max && j == k_max
            P_temp(j,1) = p_max;
        end
    end
    P_robust{1,u} = P_temp;
end
end