function [CDF] = cdf_square_mu(F_BB,F_RF,W_BB,W_RF,R_n,H,N_ds,ball_size,axis,N_test)

[N_r,N_t,U] = size(H);
CDF = zeros(length(axis),1); % N_test OR length(axis) ???
MSE_rand = zeros(N_test,sum(N_ds));
for k = 1 : N_test
    counter = 0;
    for u = 1:U
%         Delta_R = randn(N_r,N_t);
%         Delta_I = randn(N_r,N_t);
        Delta = sqrt(ball_size)*2*((rand(N_r,N_t)-0.5) + 1i*(rand(N_r,N_t)-0.5))/sqrt(2*N_t*N_r);
        %Delta = sqrt(ball_size)*rand(N_r,N_t).*(Delta./abs(Delta));
        H_eff = W_RF{1,u}'*(H(:,:,u)+Delta)*F_RF;
        MSE_rand(k,counter+1:counter+N_ds(1,u)) = diag((W_BB{1,u}'*H_eff*F_BB)*(W_BB{1,u}'*H_eff*F_BB)'...
            - 2*real(W_BB{1,u}'*H_eff*F_BB(:,counter+1:counter+N_ds(1,u)))...
            +W_BB{1,u}'*R_n{1,u}*W_BB{1,u}+eye(N_ds(1,u)));
        counter = counter + N_ds(1,u);
    end
end
q = 0;
MSE_rand = MSE_rand(:);
for r = axis
    q = q+1;
    CDF(q,1) = sum(MSE_rand<r+.0001)/(N_test*sum(N_ds));
end