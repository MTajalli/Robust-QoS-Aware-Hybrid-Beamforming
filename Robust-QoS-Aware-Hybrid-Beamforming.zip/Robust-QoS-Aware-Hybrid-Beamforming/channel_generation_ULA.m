function [H,AT] = channel_generation_ULA(N_t,N_r,N_cl)
AS = 10;
N_ray = 10;
D = 0.5;
L = N_cl*N_ray;
angle_spread = (AS/180)*pi;
alpha = zeros(L);
phi_t = zeros(L);
phi_r = zeros(L);
AT = zeros(N_t,L);
AR = zeros(N_r,L);
CH = zeros(N_r,N_t,L);
% ================== Generating the Clustered Channel======================

H1 = zeros(N_r,N_t);
for ll = 1:N_cl
    phi_mean_t = -pi + 2*pi*rand;
    phi_mean_r = -pi + 2*pi*rand;
    
    for l = (ll-1)*N_ray+1:ll*N_ray
        alpha(l) = (randn+1i*randn)/sqrt(2);
        phi_t(l) = laprand(phi_mean_t,angle_spread);
        phi_r(l) = laprand(phi_mean_r,angle_spread);
        for n = 1:N_t
            AT(n,l) = exp(1i*2*pi*D*(n-1)*sin(phi_t(l)))/sqrt(N_t);
        end
        for n = 1:N_r
            AR(n,l) = exp(1i*2*pi*D*(n-1)*sin(phi_r(l)))/sqrt(N_r);
        end
        CH(:,:,l) = alpha(l)*AR(:,l)*AT(:,l)';
        H1 = H1+CH(:,:,l);
    end
end
H = sqrt(N_t*N_r/L)*H1;
end