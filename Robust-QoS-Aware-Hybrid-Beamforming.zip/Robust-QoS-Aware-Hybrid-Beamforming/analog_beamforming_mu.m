function [F_RF,W_RF] = analog_beamforming_mu(H,N_RFt,N_RFr,N_ds)
% Faster drop-in replacement for analog_beamforming_mu.
% Row m of C*D depends only on row m of C, so the element-wise sweep over
% (m,n) can be done one column n at a time for all rows m at once. Random
% numbers are drawn in the same order as the original.
[N_r,N_t,U,~] = size(H);

W_RFADM = zeros(N_r,N_RFr,U);
for u = 1:U
    W_RFADM(:,:,u) = exp(1i*(2*pi*rand(N_r,N_RFr)-pi));
end

W_RF = cell(1,U);
for u = 1:U
    [Uu,~,~] = svd(H(:,:,u));
    Uh = Uu(:,1:N_ds(1,u));
    W = W_RFADM(:,:,u);
    W_BB2 = inv((W'*W))*W'*Uh;
    while true
        Q_w = norm(W*W_BB2-Uh,'fro');
        W = phase_sweep(W,W_BB2,Uh);
        W_BB2 = inv((W'*W))*W'*Uh;
        converge_w = norm(W*W_BB2 - Uh,'fro');
        if Q_w - (converge_w) < 0.0001
            break
        end
    end
    W_RF{1,u} = W*W_BB2;
end

H_mu = zeros(U*N_r,N_t);
q = 0;
for u = 1:U
    H_mu(q + 1:q + N_ds(1,u),:) = W_RF{1,u}'*H(:,:,u);
    q = q + N_ds(1,u);
end
H_mu = H_mu'*H_mu;
F_RFADM = exp(1i*(2*pi*rand(N_t,N_RFt)-pi));
[~,~,V_mu] = svd(H_mu);
V_mu = V_mu(:,1:sum(N_ds));
F_BB2 = inv((F_RFADM'*F_RFADM))*F_RFADM'*V_mu;
while true
    Q_f = norm(F_RFADM*F_BB2-V_mu,'fro');
    F_RFADM = phase_sweep(F_RFADM,F_BB2,V_mu);
    F_BB2 = inv((F_RFADM'*F_RFADM))*F_RFADM'*V_mu;
    converge_f = norm(F_RFADM*F_BB2-V_mu,'fro');
    if Q_f - (converge_f) < 0.0001
        break
    end
end
F_RF = F_RFADM*F_BB2;
end

function A = phase_sweep(A,B,T)
% One pass of the original (m,n) double loop, vectorized over m.
K = size(A,2);
for n = 1:K
    idx = [1:n-1, n+1:K];
    gamma = T - A(:,idx)*B(idx,:);
    b = B(n,:).';
    for m = 1:size(A,1)
        % same 1-by-N times N-by-1 product as the original, for identical rounding
        A(m,n) = exp(-1i*angle(conj(gamma(m,:))*b));
    end
end
end
