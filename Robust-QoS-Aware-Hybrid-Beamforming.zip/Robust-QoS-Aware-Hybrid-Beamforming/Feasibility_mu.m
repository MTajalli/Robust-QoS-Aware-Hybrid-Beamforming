function [Rho,flag,N_ds,feasibility_measure] = Feasibility_mu(U_u,S_u,R_n,delta_max_eff,Rho,N_ds)

[~,U] = size(Rho);
feasibility_measure = cell(1,U);
for u = 1:U
    U_temp = U_u{1,u};
    S_temp = S_u{1,u};
    R_inv = inv(R_n{1,u});
    measure_temp = zeros(N_ds(1,u),1);
    for k = 1:N_ds(1,u)
        beta = sqrt(abs(U_temp(:,k)'*R_inv*U_temp(:,k)));
        measure_temp(k,1) = delta_max_eff*beta^2/S_temp(k,k)^2;
    end
    feasibility_measure{1,u} = measure_temp;
end
max_index = zeros(1,U);
max_value = zeros(1,U);
for u = 1:U
    [max_value(1,u),max_index(1,u)] = max(feasibility_measure{1,u} - Rho{1,u});
end
[measure_max , u_max] = max(max_value);
if measure_max >= 0.0001
    k_max = max_index(1,u_max);
    feasibility_measure{1,u_max} = setdiff(feasibility_measure{1,u_max}, measure_max);
    Rho_temp = Rho{1,u_max};
    Rho_temp(k_max) = [];
    Rho{1,u_max} = Rho_temp;
    N_ds(1,u_max) = N_ds(1,u_max) - 1;
    flag = 0;
else
    flag = 1;
end
end