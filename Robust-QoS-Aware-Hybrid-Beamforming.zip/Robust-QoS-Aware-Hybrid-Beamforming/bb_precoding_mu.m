function [F_BB,Elastic] = bb_precoding_mu(H_sampled,W_BB,R_n,Rho,N_ds,q,weight)
%THIS FUNCTION COMPUTES THE BASEBAND COMBINER F_BB1 FOR ALL USERS
[N_s,U,~] = size(H_sampled);

cvx_begin quiet
    cvx_solver mosek
    variable F(sum(N_ds),sum(N_ds)) complex
    variable E(N_s,U)
    minimize sum(sum(E))*(1-weight) + weight*quad_form(vec(F),eye(sum(N_ds)*sum(N_ds)))
    subject to
    E >= 0;
    counter = 0;
    for u = 1:U
        rho_temp = Rho{1,u};
        W_temp = W_BB{1,u};
        for k = 1:N_ds(1,u)
            for j = 1:q
                B = H_sampled{k,u,j}'*W_temp(:,k);
                A = kron(eye(sum(N_ds)), B*(B)');
                A = 0.5*(A' + A);
                quad_form(vec(F),A)-2*real(F(:,counter+k)'*B) + ...
                    abs(W_temp(:,k)'*R_n{1,u}*W_temp(:,k)) + 1 <= rho_temp(k) + E(k,u);
            end
        end
        counter = counter + N_ds(1,u);
    end
cvx_end
Elastic = E;
F_BB = F;
end