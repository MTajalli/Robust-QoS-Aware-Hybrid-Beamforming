function [P_opt,F,W] = jsac_joint(H,N_s,N_RF,rho)

[N_r, N_t] = size(H);
[~, S, V] = svd(H);
F_opt = V(:,1:N_s);
[U_F, ~, ~] = svd(F_opt);
F_Temp = U_F(:, 1:N_RF);
F_RF = sqrt(inv(N_t))*F_Temp./abs(F_Temp);
H_int = H*F_RF;
[U_i,~,~] = svd(H_int);
W_Temp = U_i(:,1:N_RF);
W_RF = sqrt(inv(N_r))*W_Temp./abs(W_Temp);
H_eq = sqrtm(inv(W_RF'*W_RF))*W_RF'*H*F_RF;
[U_e,S_e,V_e] = svd(H_eq);
F_BBTemp = V_e(:,1:N_s);
%W_BB = U_e(:,1:N_s);
S_e = S_e(1:N_s,1:N_s);
Rho = rho*eye(N_s);
P = inv(S_e.^2).*(inv(Rho) - eye(N_s));
F_BB = F_BBTemp*sqrtm(P);
F = F_RF*F_BB;
W_BB = inv(H_eq*(F_BB)*F_BB'*H_eq' + W_RF'*W_RF)*H_eq*F_BB;
W = W_RF*W_BB;
p_opt = 1./diag(S(1:N_s,1:N_s).^2).*(1./rho-1);
P_opt = sum(p_opt);
end