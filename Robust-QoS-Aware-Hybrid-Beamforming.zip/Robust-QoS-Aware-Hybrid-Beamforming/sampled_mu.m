function [F_BB,W_BB,elastic] = sampled_mu(H_sampled,R_n,Rho,N_ds,q,weight)
[~,U,~] = size(H_sampled);
elastic = cell(1,U);
for u = 1:U
    elastic{1,u} = 10^4*ones(N_ds(1,u),1);
end

% ============ Feasible Initilization via Block Diagonalization ===========
counter = 0;
for u = 1:U
    Heff_u = zeros(sum(N_ds)-N_ds(1,u),sum(N_ds));
    counter_int = 0;
    uu = setdiff(1:U,u);
    for j = 1:U - 1
        Heff_u(counter_int + 1 : counter_int + N_ds(1,uu(j)),:) = H_sampled{1,uu(j),1};
        counter_int = counter_int + N_ds(1,uu(j));
    end
    [~,~,V_intu] = svd(Heff_u);
    V_0 = V_intu(:,sum(N_ds)-N_ds(1,u)+1:sum(N_ds));
    [~,S_u,V_u] = svd(sqrtm(inv(R_n{1,u}))*H_sampled{1,u,1}*V_0);
    p_hbd = 1./diag(S_u(1:N_ds(1,u),1:N_ds(1,u)).^2).*(1./Rho{1,u}-1);
    F_HBD = 2*V_0*V_u(:,1:N_ds(1,u))*sqrtm(diag(p_hbd)); % 2 is multiplied to ensure feasible initialization
    F_BB(:,counter + 1 : counter + N_ds(1,u)) = F_HBD;
    counter = counter + N_ds(1,u);
end

% ======================= Alternating Minimization ========================
r = 0;
N_it = 100;
while true
    SUM = 0;
    for u = 1:U
    SUM = SUM + sum(elastic{1,u});
    end
    Q = (1 - weight)*SUM + weight*norm(F_BB,'fro')^2;
    r = r+1;
    W_BB = bb_combining_mu(H_sampled,F_BB,R_n,N_ds,q);
    [F_BB, Elastic] = bb_precoding_mu(H_sampled,W_BB,R_n,Rho,N_ds,q,weight);
    for u = 1:U
        elastic{1, u} = Elastic(1 : N_ds(1, u), u);
    end
    if Q - ((1 - weight)*sum(sum(Elastic)) + weight*norm(F_BB, 'fro')^2) <= .001 || r >= N_it
        break
    end
end
end