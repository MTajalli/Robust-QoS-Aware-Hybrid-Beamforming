function [x] = laprand(mu,sigma)
u1=rand;
u2=rand;
x=log(u1/u2);
x=x/sqrt(2);
x=x*sigma;
x=x+mu;
end