%% =======================  Description  ==================================
% This files prints the plot of Fig. 5 in the paper for spectral efficieny
% of single-user systems with respect to SNR for our HB methods (Iterative
% and Low-complexity) in fully-connected and partially-connected structures,
% fully digital robust SDP-based method, non-robust state-of-the-art HB
% method in [7], and non-robust fully digital methods.



%% ==========================System Parameters=============================
clear
clc
cvx_quiet true
%
N_t = 20; % input('Number of Horizontal Transmitter Antennas: ');
N_r = 8; % input('Number of Horizontal Receiver Antennas: ');
N_cl = 3; % input('Number of Channel Clusters: ');
N_s = 2; % input('Number of Data Streams: ');
N_RFt = 4; % input('Number of RF Chains at Transmitter: ');
N_RFr = 4; % input('Number of RF Chains at Receiver: ');
U = 1; % input('Number of Users: ');
structure_flag = 1; % Structure Flag (FCS = 1 and PCS =0)


N_it = 1000;

N_RF = N_RFt;

delta_max = 1.034;
delta_max_eff_fcs = 0.258;
delta_max_eff_pcs = 0.202;


QoS_range = 0.1:0.1:0.9;

Rate_range = N_s*log2(1./QoS_range);


Rate_sdp = zeros(length(QoS_range),length(delta_max));
Rate_it_fcs = zeros(length(QoS_range),length(delta_max));
Rate_lc_fcs = zeros(length(QoS_range),length(delta_max));
Rate_it_pcs = zeros(length(QoS_range),length(delta_max));
Rate_lc_pcs = zeros(length(QoS_range),length(delta_max));
Rate_perfect = zeros(length(QoS_range),length(delta_max));
Rate_jsac = zeros(length(QoS_range),length(delta_max));

P_sdp = zeros(length(QoS_range),1);
P_it_fcs = zeros(length(QoS_range),1);
P_lc_fcs = zeros(length(QoS_range),1);
P_it_pcs = zeros(length(QoS_range),1);
P_lc_pcs = zeros(length(QoS_range),1);
P_perfect = zeros(length(QoS_range),1);
P_jsac = zeros(length(QoS_range),1);


% H = zeros(N_r,N_t,U,N_max);
% for u = 1:U
%     for k = 1:N_max
%         [H(:,:,u,k), ~] = channel_generation_ULA(N_t, N_r, N_cl);
%     end
% end

load('H_sdp') % Named 'H_sdp' in MATLAB environment
% load('H_sdp_rate') % Named 'H' in MATLAB environment
%H = H_sdp_rate;
H = H_sdp;

weight = 0.1;
% Feasible = 0;

num_QoS = length(QoS_range);

%parpool('local', 10)

for q = 1 : num_QoS
    
    QoS = QoS_range(q);

    disp('QoS:')
    disp(QoS)
    
    [F_sdp,W_sdp,P_new,Flag] = fun_sdp(H,N_s,QoS,delta_max);

    P_sdp(q,1) = P_new;

    [~,~,F_BB_it_fcs,F_RF_it_fcs,W_BB_it_fcs,W_RF_it_fcs,N_ds_it_fcs] = ...
        fun_iterative(H,N_s,N_RFr,N_RFt,structure_flag,QoS,delta_max_eff_fcs,weight);

    F_it_fcs = F_RF_it_fcs*F_BB_it_fcs;
    W_it_fcs = W_RF_it_fcs{1,1}*W_BB_it_fcs{1,1};

    P_it_fcs(q,1) = norm(F_it_fcs,'fro')^2;

    [~,F_BB_lc_fcs,F_RF_lc_fcs,W_BB_lc_fcs,W_RF_lc_fcs,N_ds_lc_fcs] =...
        fun_low_complexity(H,N_s,N_RFr,N_RFt,structure_flag,QoS,delta_max_eff_fcs);

    F_lc_fcs = F_RF_lc_fcs*F_BB_lc_fcs;
    W_lc_fcs = W_RF_lc_fcs{1,1}*W_BB_lc_fcs{1,1};

    P_lc_fcs(q,1) = norm(F_lc_fcs,'fro')^2;


    [~,~,F_BB_it_pcs,F_RF_it_pcs,W_BB_it_pcs,W_RF_it_pcs,N_ds_it_pcs] = ...
        fun_iterative(H,N_s,N_RFr,N_RFt,structure_flag-1,QoS,delta_max_eff_pcs,weight);

    F_it_pcs = F_RF_it_pcs*F_BB_it_pcs;
    W_it_pcs = W_RF_it_pcs{1,1}*W_BB_it_pcs{1,1};

    P_it_pcs(q,1) = norm(F_it_pcs,'fro')^2;


    [~,F_BB_lc_pcs,F_RF_lc_pcs,W_BB_lc_pcs,W_RF_lc_pcs,N_ds_lc_pcs] =...
        fun_low_complexity(H,N_s,N_RFr,N_RFt,structure_flag-1,QoS,delta_max_eff_pcs);

    F_lc_pcs = F_RF_lc_pcs*F_BB_lc_pcs;
    W_lc_pcs = W_RF_lc_pcs{1,1}*W_BB_lc_pcs{1,1};

    P_lc_pcs(q,1) = norm(F_lc_pcs,'fro')^2;

    [~,F_BB_perfect,F_RF_perfect,W_BB_perfect,W_RF_perfect,N_ds_perfect] =...
        fun_low_complexity(H,N_s,N_RFr,N_RFt,structure_flag,QoS,0);

    F_perfect = F_RF_perfect*F_BB_perfect;
    W_perfect = W_RF_perfect{1,1}*W_BB_perfect{1,1};

    P_perfect(q,1) = norm(F_perfect,'fro')^2;
    
    [~,F_jsac,W_jsac] = jsac_joint(H,N_s,N_RF,QoS);
    
    P_jsac(q,1) = norm(F_jsac,'fro')^2;
    
    Rate_temp1 = 0;
    Rate_temp2 = 0;
    Rate_temp3 = 0;
    Rate_temp4 = 0;
    Rate_temp5 = 0;
    Rate_temp6 = 0;
    Rate_temp7 = 0;

    for k = 1 : N_it

        Error = randn(N_r,N_t) + 1i*randn(N_r,N_t);
        Error = rand*delta_max*Error/norm(Error,'fro');
        H_error = H + Error;

        Rate_temp1 = Rate_temp1 + sumrate(F_sdp,W_sdp,H_error);
        Rate_temp2 = Rate_temp2 + sumrate(F_it_fcs,W_it_fcs,H_error);
        Rate_temp3 = Rate_temp3 + sumrate(F_lc_fcs,W_lc_fcs,H_error);
        Rate_temp4 = Rate_temp4 + sumrate(F_it_pcs,W_it_pcs,H_error);
        Rate_temp5 = Rate_temp5 + sumrate(F_lc_pcs,W_lc_pcs,H_error);
        Rate_temp6 = Rate_temp6 + sumrate(F_perfect,W_perfect,H_error);
        Rate_temp7 = Rate_temp7 + sumrate(F_jsac,W_jsac,H_error);
    end

    Rate_sdp(q,1) = Rate_temp1/N_it;
    Rate_it_fcs(q,1) = Rate_temp2/N_it;
    Rate_lc_fcs(q,1) = Rate_temp3/N_it;
    Rate_it_pcs(q,1) = Rate_temp4/N_it;
    Rate_lc_pcs(q,1) = Rate_temp5/N_it;
    Rate_perfect(q,1) = Rate_temp6/N_it;
    Rate_jsac(q,1) = Rate_temp7/N_it;
    
end

figure
hold on
grid on

plot(10*log10(P_perfect),Rate_range,'k-p','markersize',10,'linewidth',2)
plot(10*log10(P_jsac),Rate_range,'m-h','markersize',10,'linewidth',2)
plot(10*log10(P_it_fcs),Rate_range,'b-o','markersize',10,'linewidth',2)
plot(10*log10(P_lc_fcs),Rate_range,'g-s','markersize',10,'linewidth',2)
plot(10*log10(P_it_pcs),Rate_range,'b-^','markersize',10,'linewidth',2)
plot(10*log10(P_lc_pcs),Rate_range,'g-v','markersize',10,'linewidth',2)
plot(10*log10(P_sdp),Rate_range,'r-+','markersize',10,'linewidth',2)


legend('Fully Digital, Perfect CSI', 'HB (FCS), Perfect CSI [7]','Iterative (FCS), \epsilon_{eff} = 0.26',...
'Low-Complexity (FCS), \epsilon_{eff} = 0.26', 'Iterative (PCS), \epsilon_{eff} = 0.20',...
'Low-Complexity (PCS), \epsilon_{eff} = 0.20','SDP, \epsilon = 1.03','fontsize',9)
    

xlabel('SNR (dB)','fontsize', 18, 'FontName', 'Times New Roman')
ylabel('Spectral Efficiency (bps/Hz)','fontsize', 18, 'FontName', 'Times New Roman')