%% =======================  Description  ==================================
% This files prints the plot of Fig. 8 in the paper for outage probability of
% multi-user systems with respect to channel estimation error std in [0, 0.5]
% for our HB methods (Iterative and Low-complexity), and state-of-the-art
% non-robust HB methods in [5], [6], and [8].


%% ==========================System Parameters=============================
clear
clc
cvx_quiet true


N_t = 64; % input('Number of Horizontal Transmitter Antennas: ');
N_r = 16; % input('Number of Horizontal Receiver Antennas: ');
N_s = 2; % input('Number of Data Streams: ');
N_RFt = 4; % input('Number of RF Chains at Transmitter: ');
N_RFr = 2; % input('Number of RF Chains at Receiver: ');
U = 2; % input('Number of Users: ');
N_test = 10^4;
N_it = 1;
N_cl = 3;

structure_flag = 1; % Structure Flag (FCS = 1 and PCS =0)

% delta_max_range = [ 0.0147,1.034];
% delta_max_range = 3.3572;
delta_max_eff = [.113,.258];
% delta_max_eff = .4472;

num_delta = length(delta_max_eff);

QoS = 0.2;
rho = QoS*ones(N_s,1);
sigma_n = 1;
sigma_e = 0 : 0.01 : 1;

Outage_it = zeros(length(sigma_e), length(delta_max_eff));
Outage_lc = zeros(length(sigma_e), length(delta_max_eff));

%H = sqrt(1/2)*(randn(N_r,N_t,U)+1i*randn(N_r,N_t,U));
H = zeros(N_r,N_t,U);
for u = 1:U
    [H(:,:,u), ~] = channel_generation(N_t, N_r, N_cl);
end

[F_RF_one, F_BB_one, W_RF_one, W_BB_one] = non_robust_one(H,N_s,N_RFr,N_RFt,QoS);
[F_RF_dft, F_BB_dft, W_RF_dft, W_BB_dft] = non_robust_dft(H,N_s,N_RFr,N_RFt,QoS);
[F_RF_arab,F_BB,W_RF,W_BB] = arab(H,N_RFt,N_RFr,N_s,rho);

Rn_one = cell(1,U);
Rho = cell(1,U);
Rn_dft = cell(1,U);

N_ds = N_s*ones(1,U);

Rn_arab = cell(1,U);

W_RF_arab = cell(1,U);
W_BB_arab = cell(1,U);
F_BB_arab = zeros(N_RFt,U*N_s);

for u = 1:U
    W_BB_arab{1,u} = W_BB(:,:,u);
    W_RF_arab{1,u} = W_RF(:,:,u);
    F_BB_arab(:,(u-1)*N_s + 1 : u*N_s) = F_BB(:,:,u);
    
    Rn_one{1,u} = sigma_n^2*W_RF_one{1,u}'*W_RF_one{1,u};
    Rn_dft{1,u} = sigma_n^2*W_RF_dft{1,u}'*W_RF_dft{1,u};
    
    Rho{1,u} = QoS*ones(1,U);
    Rn_arab{1,u} = sigma_n^2*W_RF_arab{1,u}'*W_RF_arab{1,u};
end


Outage_one = outage_mu(H,F_BB_one,F_RF_one,W_BB_one,W_RF_one,Rn_one,Rho,N_ds,sigma_e,N_test);
Outage_dft = outage_mu(H,F_BB_dft,F_RF_dft,W_BB_dft,W_RF_dft,Rn_dft,Rho,N_ds,sigma_e,N_test);
Outage_arab = outage_mu(H,F_BB_arab,F_RF_arab,W_BB_arab,W_RF_arab,Rn_arab,Rho,N_ds,sigma_e,N_test);

save('Outage_one','Outage_one')
save('Outage_dft','Outage_dft')
save('Outage_arab','Outage_arab')

weight = 0.01;
parpool('local', num_delta)

parfor s = 1 : num_delta
    
    delta_max = delta_max_eff(s);
    disp('delta_max:')
    disp(delta_max)
    
    [flag_it,CUT,F_BB_it,F_RF_it,W_BB_it,W_RF_it,N_ds_it] = ...
        fun_iterative(H,N_s,N_RFr,N_RFt,structure_flag, QoS,delta_max,weight);
    Rn_it = cell(1,U);
    Rho_it = cell(1,U);
    for u = 1:U
        Rn_it{1,u} = sigma_n^2*W_RF_it{1,u}'*W_RF_it{1,u};
        Rho_it{1,u} = QoS*ones(1,N_ds_it(1,u));
    end
    
    Outage_it(:,s) = outage_mu(H,F_BB_it,F_RF_it,W_BB_it,W_RF_it,Rn_it,Rho_it,N_ds_it,sigma_e,N_test);
    
    [flag_lc,F_BB_lc,F_RF_lc,W_BB_lc,W_RF_lc,N_ds_lc] =...
        fun_low_complexity(H,N_s,N_RFr,N_RFt,structure_flag, QoS,delta_max);
    
    Rn_lc = cell(1,U);
    Rho_lc = cell(1,U);
    for u = 1:U
        Rn_lc{1,u} = sigma_n^2*W_RF_lc{1,u}'*W_RF_lc{1,u};
        Rho_lc{1,u} = QoS*ones(1,N_ds_lc(1,u));
    end
    
    Outage_lc(:,s) = outage_mu(H,F_BB_lc,F_RF_lc,W_BB_lc,W_RF_lc,Rn_lc,Rho_lc,N_ds_lc,sigma_e,N_test);
    
    % save('Outage_it','Outage_it')
    % save('Outage_lc','Outage_lc')
end

hold on
grid on
xlabel('$\sigma_{\rm e}$','fontsize',14, 'Interpreter','latex')
ylabel('Outage Probability','fontsize',14,'FontName','Times New Roman')
sigma_e = 0 : 0.01 : 1;
plot(sigma_e,smooth(Outage_dft),'r-diamond','linewidth',2,'markersize',8,'markerindices',1:10:101)
plot(sigma_e,smooth(Outage_one),'c*-','Color',[0.93,0.69,0.13],'linewidth',2,'markersize',10,'markerindices',1:10:101)
plot(sigma_e,smooth(Outage_arab),'pentagram--','Color',[1.00,0.07,0.65],'linewidth',2,'markersize',8,'markerindices',1:10:101)
plot(sigma_e,smooth(Outage_it(:,1)),'bo-','linewidth',2,'markersize',8,'markerindices',1:10:101)
plot(sigma_e,smooth(Outage_lc(:,1)),'gsquare-','linewidth',2,'markersize',8,'markerindices',1:10:101)
plot(sigma_e,smooth(Outage_it(:,2)),'bo--','linewidth',2,'markersize',8,'markerindices',1:10:101)
plot(sigma_e,smooth(Outage_lc(:,2)),'gsquare--','linewidth',2,'markersize',8,'markerindices',1:10:101)

legend('Non-robust [5]','Non-robust [6]', 'ARAB','It, $\epsilon_{\rm eff} = 0.113$','LC, $\epsilon_{\rm eff} = 0.113$',...
    'It, $\epsilon_{\rm eff} = 0.258$','LC, $\epsilon_{\rm eff} = 0.258$',...
    'fontsize',10, 'Interpreter', 'latex','location', 'best')