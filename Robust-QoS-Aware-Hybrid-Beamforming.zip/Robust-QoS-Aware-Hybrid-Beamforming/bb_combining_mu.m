function [W_BB] = bb_combining_mu(H_sampled,F_BB,R_n,N_ds, q)
%THIS FUNCTION COMPUTES THE BASEBAND COMBINER W_BB1 FOR ALL USERS
[~,U,~] = size(H_sampled);
W_BB = cell(1,U);
A = cell(1,q);
B = cell(1,q);
counter = 0;
for u = 1:U
    W_temp = zeros(N_ds(1,u),N_ds(1,u));
    for k = 1:N_ds(1,u)
        for j = 1:q
            B{1,j} = H_sampled{k,u,j}*F_BB(:,counter + 1:counter + N_ds(1,u));
            A{1,j} = H_sampled{k,u,j}*F_BB*(H_sampled{k,u,j}*F_BB)'+R_n{1,u};
        end
        cvx_begin quiet
        cvx_solver mosek
        variable w(N_ds(1,u),1) complex
        variable tau
        minimize tau
        subject to
        for j = 1:q
            B_temp = B{1,j};
            quad_form(w,A{1,j}) - 2*real(w'*B_temp(:,k)) + 1 <= tau;
        end
        cvx_end
        W_temp(:,k) = w;
    end
    W_BB{1,u} = W_temp;
    counter = counter + N_ds(1,u);
end