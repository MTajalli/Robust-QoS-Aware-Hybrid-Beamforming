function [Feasibility_flag,F_BB,F_RF,W_BB,W_RF,N_ds] =...
    fun_low_complexity(H, N_s, N_RFr, N_RFt, structure_flag, QoS, delta_max_eff)

% ==========================System Parameters==============================
[~,~,U] = size(H);
rho = QoS*ones(N_s,U);
Rho = cell(1,U);
N_ds = N_s*ones(1,U);
for u = 1:U
    Rho{1,u} = rho(:,u);
end
sigma_n = 1;

% ====================== Robust Hybrid Beamforming ========================
  
while true
    if structure_flag == 1
    [F_RF,W_RF] = analog_beamforming_mu(H,N_RFt,N_RFr,N_ds); % F_RF: (N_t,sum(N_ds)), W_RF: cell(1,U)
    else
        [F_RF,W_RF] = analog_beamforming_mu_pcs(H,N_RFt,N_RFr,N_ds);
    end
%     else
        F_RF = F_RF(:,1:sum(N_ds));
        for u = 1:U
            W_temp = W_RF{1,u};
            W_RF{1,u} = W_temp(:,1:N_ds(1,u));
        end
%     end
    H_eff = cell(1,U);
    R_n = cell(1,U);
    for u = 1:U
        R_n{1,u} = sigma_n^2*(W_RF{1,u})'*W_RF{1,u};
        H_eff{1,u} = W_RF{1,u}'*H(:,:,u)*F_RF;
    end
    % ===================== BLOCK DIAGONALIZATION  ========================
    U_u = cell(1,U);
    S_u = cell(1,U);
    V_u = cell(1,U);
    V_0 = cell(1,U);
    for u = 1:U
        Heff_u = zeros(sum(N_ds)-N_ds(1,u),sum(N_ds));
        counter = 0;
        uu = setdiff(1:U,u);
        for j = 1:U - 1
            Heff_u(counter + 1 : counter + N_ds(1,uu(j)),:) = H_eff{1,uu(j)};
            counter = counter + N_ds(1,uu(j));
        end
        [~,~,V_intu] = svd(Heff_u);
        V_0{1,u} = V_intu(:,sum(N_ds)-N_ds(1,u)+1:sum(N_ds));
        [U_u{1,u},S_u{1,u},V_u{1,u}] = svd(sqrtm(inv(R_n{1,u}))*H_eff{1,u}*V_0{1,u});
    end
    % =====================================================================
    
    [Rho,flag,N_ds,feasibility_measure] = Feasibility_mu(U_u,S_u,R_n,delta_max_eff,Rho,N_ds);
    for u = 1:U
        % disp (u)
        % disp (feasibility_measure{1,u})
        if isempty(Rho{1,u}) == 1
            U = U - 1;
            N_ds(:,u) = [];
            Rho(:,u) = [];
            H(:,:,u) = [];
            % disp('ONE USER IS OUT')
            break
        end
    end
    if U == 0
        break
    end
    if flag == 1
        break
    end
end
if U == 0
    Feasibility_flag = 0;
    N_ds = 0;
    F_BB = 0;
    W_BB = 0;
else
    Feasibility_flag = 1;
    beta = cell(1,U);
    for u =1:U
        U_temp = U_u{1,u};
        beta_temp = zeros(N_ds(1,u),1);
        for j = 1:N_ds(1,u)
            beta_temp(j,1) = sqrt(abs(U_temp(:,j)'*inv(R_n{1,u})*U_temp(:,j)));
        end
        beta{1,u} = beta_temp;
    end
    P_robust = PA_lesscomplex_mu(Rho,beta,S_u,N_ds,sqrt(delta_max_eff));
    F_BB = zeros(sum(N_ds),sum(N_ds));
    W_BB = cell(1,U);
    counter = 0;
    for u = 1:U
        F_BBu = V_0{1,u}*V_u{1,u}*sqrtm(diag(P_robust{1,u}));
        F_BB(:,counter + 1:counter + N_ds(1,u)) = F_BBu;
        W_BB{1,u} = inv(H_eff{1,u}*(F_BBu)*F_BBu'*H_eff{1,u}'+R_n{1,u})*H_eff{1,u}*F_BBu;
        counter = counter + N_ds(1,u);
    end
    MSE_nom = cell(1,U);
    counter = 0;
    for u = 1:U
        MSE_nom{1,u} = diag((W_BB{1,u}'*H_eff{1,u}*F_BB)*(W_BB{1,u}'*H_eff{1,u}*F_BB)'...
            - 2*real(W_BB{1,u}'*H_eff{1,u}*F_BB(:,counter+1:counter+N_ds(1,u)))...
            +W_BB{1,u}'*R_n{1,u}*W_BB{1,u}+eye(N_ds(1,u)));
        counter = counter + N_ds(1,u);
    end
end
end