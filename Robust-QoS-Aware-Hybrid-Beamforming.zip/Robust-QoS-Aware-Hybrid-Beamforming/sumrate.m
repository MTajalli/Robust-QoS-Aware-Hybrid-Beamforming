function [sum_rate] = sumrate(F,W,H)

[~,N_s] = size(F);
R_n = W'*W;
sum_rate = log2( det( eye(N_s) + inv(R_n)*(W'*H*F)*(W'*H*F)'));
end

