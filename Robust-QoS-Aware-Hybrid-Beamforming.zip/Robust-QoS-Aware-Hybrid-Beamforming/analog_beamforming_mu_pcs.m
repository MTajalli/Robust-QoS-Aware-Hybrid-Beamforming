function [F_RF,W_RF] = analog_beamforming_mu_pcs(H,N_RFt,N_RFr,N_ds)
[N_r,N_t,U] = size(H);

W_RFADM = zeros(N_r,N_RFr,U);

W_BB2 = cell(1,U);

Uh = cell(1,U);

W_RF = cell(1,U);
M_t = N_t/N_RFt;
M_r = N_r/N_RFr;

for u = 1:U
    [Uu,~,~] = svd(H(:,:,u));
    Uh{1,u} = Uu(:,1:N_ds(1,u));
    W_RFADM(:,:,u) = zeros(N_r,N_RFr);
    for n = 1:N_RFr
        for m = (n-1)*M_r+1:n*M_r
            W_RFADM(m,n,u) = exp(1i*angle(Uu(m,n)));
        end
    end
    W_BB2{1,u} = inv((W_RFADM(:,:,u)'*W_RFADM(:,:,u)))*W_RFADM(:,:,u)'*Uh{1,u};
end
for u = 1:U
    W_temp = W_BB2{1,u};
    U_temp = Uh{1,u};
    k_w = 1;
    while true
        Q_w = norm(W_RFADM(:,:,u)*W_BB2{1,u}-Uh{1,u},'fro');
        for n = 1:N_RFr
            for m = (n-1)*M_r+1:n*M_r
                delta_r = sum(conj(U_temp(m,:)).*W_temp(n,:));
                W_RFADM(m,n,u) = exp(-1i*angle(delta_r));
                W_BB2{1,u} = inv((W_RFADM(:,:,u)'*W_RFADM(:,:,u)))*W_RFADM(:,:,u)'*Uh{1,u};
            end
        end
        
        converge_w = norm(W_RFADM(:,:,u)*W_BB2{1,u} - Uh{1,u},'fro');
        if Q_w - (converge_w) < 0.001
            break
        end
        k_w = k_w+1;
    end
    W_RF{1,u} = W_RFADM(:,:,u)*W_BB2{1,u};
end
H_mu = zeros(sum(N_ds),N_t);
q = 0;
for u=1:U
    H_mu(q + 1:q + N_ds(1,u),:) = W_RF{1,u}'*H(:,:,u);
    q = q + N_ds(1,u);
end
[~, ~, V_mu] = svd(H_mu);
F_RFADM = zeros(N_t,N_RFt);
for n = 1:N_RFt
    for m = (n-1)*M_t+1:n*M_t
        F_RFADM(m,n) = exp(1i*angle(V_mu(m,n)));
    end
end
V_mu = V_mu(:,1:sum(N_ds));
F_BB2 = inv((F_RFADM'*F_RFADM))*F_RFADM'*V_mu;
k_f = 1;
while true
    Q_f = norm(F_RFADM*F_BB2-V_mu,'fro');
    for n = 1:N_RFt
        for m = (n-1)*M_t+1:n*M_t
            delta_t = sum(conj(V_mu(m,:)).*F_BB2(n,:));
            F_RFADM(m,n) = exp(-1i*angle(delta_t));
            F_BB2 = inv(F_RFADM'*F_RFADM)*F_RFADM'*V_mu;
        end
    end
    converge_f = norm(F_RFADM*F_BB2-V_mu,'fro');
    if Q_f-(converge_f) < 0.001
        break
    end
    k_f=k_f+1;
end
F_RF = F_RFADM*F_BB2;
end