function [G,F,P_new,Flag] = fun_sdp(H,N_s,QoS,delta_max)

cvx_quiet true

[N_r,~,U,~] = size(H);

mu = QoS*ones(N_s,U);

% ====================== Robust Hybrid Beamforming ========================
P_new = 1e8;
cut_off = .01;
F = zeros(N_r,N_s,U);
for u = 1:U
    [Uh,~,~] = svd(H(:,:,u));
    F(:,:,u) = Uh(:,1:N_s);
end
% F = (randn(N_r,N_s,U) + 1i*randn(N_r,N_s,U));
% MSE_nom = zeros(N_s,U);
counter = 0;
while true
    P_old = P_new;
    counter = counter + 1;
    if counter == 1
        [P_new, G, ~, p, cvx_status] = fd_precoder(H,F,mu,delta_max);
        if strcmp(cvx_status,'Infeasible') == 1
            Flag = 0;
            break
        else
       % elseif strcmp(cvx_status,'Solved') == 1
            Flag = 1;
        end
        for u = 1:U
            for n = 1:N_s
                F(:,n,u) = F(:,n,u)/p(n,u);
            end
        end
    end
    if counter >= 2
        [P_new, G, ~] = fd_precoder_initial(H,F,mu,delta_max);
    end

    F = fd_combiner(H,G,delta_max);
    if P_old - P_new <= cut_off
        break
    end

end

end

