function [Outage] = outage_mu(H,F_BB,F_RF,W_BB,W_RF,R_n,Rho,N_ds,sigma_e,N_test)

[N_r,N_t,U] = size(H);
Outage = zeros(length(sigma_e),1);
q=0;
for variance_e = sigma_e
%     disp('Error Variance:')
%     disp(variance_e)
    q = q+1;
    for k = 1 : N_test
        counter = 0;
        for u = 1:U
            Delta = (variance_e/sqrt(2)) * (randn(N_r,N_t) + 1i*randn(N_r,N_t));
            H_eff = W_RF{1,u}'*(H(:,:,u)+Delta)*F_RF;
            MSE_nom = diag((W_BB{1,u}'*H_eff*F_BB)*(W_BB{1,u}'*H_eff*F_BB)'...
                - 2*real(W_BB{1,u}'*H_eff*F_BB(:,counter+1:counter+N_ds(1,u)))...
                +W_BB{1,u}'*R_n{1,u}*W_BB{1,u}+eye(N_ds(1,u)));
            counter = counter + N_ds(1,u);
            Outage(q,1) = Outage(q,1) + sum(MSE_nom > Rho{1,u}'+.0001);
        end
    end
    Outage(q,1) = Outage(q,1)/(N_test*sum(N_ds));
end
end