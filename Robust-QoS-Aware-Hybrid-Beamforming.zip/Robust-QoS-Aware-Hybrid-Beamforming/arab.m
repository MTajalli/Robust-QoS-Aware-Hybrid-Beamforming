function [F_RF,F_BB,W_mu,W_BB] = arab(H,N_RFt,N_RFr,N_s,rho)

[N_r,N_t,U,~] = size(H);
F = randn(N_t,N_RFt) + 1i*randn(N_t,N_RFt);
F = F./abs(F);
W = zeros(U*N_r,U*N_RFr);
H_mu = zeros(U*N_r,N_t);
for u = 1:U
    W_temp = randn(N_r,N_RFr) + 1i*randn(N_r,N_RFr);
    W((u-1)*N_r + 1 : u*N_r , (u-1)*N_RFr + 1 : u*N_RFr) = W_temp./abs(W_temp);
    H_mu((u-1)*N_r + 1 : u*N_r,:) = H(:,:,u);
end
while true
    %============================= Updating F =============================
    Conv_index_old = log2(det(eye(U*N_RFr) + W'*H_mu*(F)*F'*H_mu'*W));
    H_tilde = W'*H_mu;
    E = eye(U*N_RFr);
    F_RF = [];
    for j = 1:N_RFt
        G = H_tilde'*inv(E)*H_tilde;
        while true
            F_conv = F(:,j);
            for i = 1:N_t
                F(i,j) = G(i,:)*F(:,j)/abs(G(i,:)*F(:,j));
            end
            x_1 = log2(1+abs(F_conv'*H_tilde'*inv(E)*H_tilde*F_conv));
            x_2 = log2(1+abs(F(:,j)'*H_tilde'*inv(E)*H_tilde*F(:,j)));
            %             disp(x_2 - x_1)
            if x_2 - x_1 < 0.01
                break
            end
        end
        F_RF = [F_RF , F(:,j)];
        E = eye(U*N_RFr) + H_tilde*(F_RF)*F_RF'*H_tilde';
    end
    F = F_RF;
    % ============================= Updating W ============================
    H_hat = F'*H_mu';
    S = eye(N_RFt);
    W_RF = [];
    for j = 1:U*N_RFr
        C = H_hat'*inv(S)*H_hat;
        while true
            W_conv = W(:,j);
            alpha = floor((j-1)/N_RFr);
            for i = alpha*N_r + 1 : (alpha+1)*N_r
                W(i,j) = C(i,:)*W(:,j)/abs(C(i,:)*W(:,j));
            end
            
            y_1 = log2(1+abs(W_conv'*H_hat'*inv(S)*H_hat*W_conv));
            y_2 = log2(1+abs(W(:,j)'*H_hat'*inv(S)*H_hat*W(:,j)));
            %             disp(y_2 - y_1)
            if y_2 - y_1 < 0.01
                break
            end
        end
        W_RF = [W_RF , W(:,j)];
        S = eye(N_RFt) + H_hat*(W_RF)*W_RF'*H_hat';
    end
    Conv_index_new = log2(det(eye(U*N_RFr) + W'*H_mu*(F)*F'*H_mu'*W));
%     disp(Conv_index_old)
%     disp(Conv_index_new)
    if Conv_index_new - Conv_index_old < 0.01
        break
    end
end
% ===================== Block Diagonalization =============================
W_mu = zeros(N_r,N_RFr,U);
for u = 1:U
    W_mu(:,:,u) = W((u-1)*N_r + 1 : u*N_r , (u-1)*N_RFr + 1 : u*N_RFr);
end
Heff = zeros(N_RFr,N_RFt,U);
Heff_u = zeros((U-1)*N_RFr,N_RFt,U);
for u = 1:U
    Heff(:,:,u) = W_mu(:,:,u)'*H(:,:,u)*F;
end
V_0 = zeros(N_RFt,N_RFt-(U-1)*N_RFr,U);
F_BB = zeros(N_RFt,N_s,U);
W_BB = zeros(N_RFr,N_s,U);
MSE_HBD = zeros(N_s,N_s,U);
for u = 1:U
    for uu = setdiff(1:U,u)
        Heff_u((uu-1)*N_RFr+1:uu*N_RFr,:,u) = Heff(:,:,uu);
    end
    R_nu = W_mu(:,:,u)'*W_mu(:,:,u);
    [~,~,V_intu] = svd(Heff_u(:,:,u));
    V_0(:,:,u) = V_intu(: , (U-1)*N_RFr + 1 : N_RFt);
    [~,S_u,V_u] = svd(sqrtm(inv(R_nu))*Heff(:,:,u)*V_0(:,:,u));
    
    P = 1./diag(S_u(1:N_s,1:N_s).^2).*(1./rho - 1);
    
    F_BB(:,:,u) = V_0(:,:,u)*V_u(:,1:N_s)*sqrtm(diag(P));
    W_BB(:,:,u) = inv(Heff(:,:,u)*F_BB(:,:,u)*F_BB(:,:,u)'*Heff(:,:,u)' + R_nu)*Heff(:,:,u)*F_BB(:,:,u);
    MSE_HBD(:,:,u)=(W_BB(:,:,u)'*Heff(:,:,u)*F_BB(:,:,u) - eye(N_s))*...
        (W_BB(:,:,u)'*Heff(:,:,u)*F_BB(:,:,u) - eye(N_s))' + W_BB(:,:,u)'*R_nu*W_BB(:,:,u);
%     disp(MSE_HBD(:,:,u))
end
end

