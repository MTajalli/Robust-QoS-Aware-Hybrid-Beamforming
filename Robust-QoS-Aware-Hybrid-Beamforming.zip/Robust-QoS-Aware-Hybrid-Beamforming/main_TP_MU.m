%% =======================  Description  ==================================
% This files prints the plot of Fig. 9 in the paper for transmit power of
% multi-user systems with respect to MSE target values in [0.1, 0.2] for our
% HB methods (Iterative and Low-complexity) in fully-connected and partially-
% connected structures, and state-of-the-art non-robust HB methods in [5], 
% [6], and [8].


%%==========================System Parameters==============================
clear
clc
cvx_quiet true


N_t = 100; % input('Number of Horizontal Transmitter Antennas: ');
N_r = 16; % input('Number of Horizontal Receiver Antennas: ');
N_s = 2; % input('Number of Data Streams: ');
N_RFr = 3; % input('Number of RF Chains at Receiver: ');
U = 4; % input('Number of Users: ');
N_RFt = 12; % input('Number of RF Chains at Transmitter: ');
structure_flag = 1; % Structure Flag (FCS = 1 and PCS =0)

N_it = 1;
% delta_max_range = [0,0.463,1.034];
delta_max_eff = [0, 0.5, 1];
% delta_max_eff = 1;
QoS_range = 0.1:0.01:0.2;
% QoS_range = 0.1;
num_delta = length(delta_max_eff);
num_QoS = length(QoS_range);

P_it_fcs_mu = zeros(length(QoS_range),length(delta_max_eff));
P_lc_fcs_mu = zeros(length(QoS_range),length(delta_max_eff));
P_it_pcs_mu = zeros(length(QoS_range),length(delta_max_eff));
P_lc_pcs_mu = zeros(length(QoS_range),length(delta_max_eff));

% H = sqrt(1/2)*(randn(N_r,N_t,U,N_it)+1i*randn(N_r,N_t,U,N_it));
% load('H_MU');
% load('H_MU_gamma')
N_cl = 3;
H = zeros(N_r,N_t,U,N_it);
for u = 1:U
    for k = 1:N_it
        [H(:,:,u,k), ~] = channel_generation(N_t, N_r, N_cl);
    end
end

weight = 1e-1;
for s = 1 : num_delta
    
    delta_max = delta_max_eff(s);
    disp('delta_max:')
    disp(delta_max)
    parfor r = 1: num_QoS
        QoS = QoS_range(r);
        disp('QoS:')
        disp(QoS)
        P_temp_it_fcs = zeros(N_it,1);
        P_temp_lc_fcs = zeros(N_it,1);
        P_temp_it_pcs = zeros(N_it,1);
        P_temp_lc_pcs = zeros(N_it,1);

        for k = 1:N_it
%             disp('Channel Number')
%             disp(k)
            
            [~,~,F_BB_it_fcs,F_RF_it_fcs,~,~,~] = ...
                fun_iterative(H(:,:,:,k),N_s,N_RFr,N_RFt,structure_flag,QoS,delta_max_eff(s),weight);
            P_temp_it_fcs(k,1) = norm(F_RF_it_fcs*F_BB_it_fcs,'fro')^2;
            
            [~,F_BB_lc_fcs,F_RF_lc_fcs,~,~,~] =...
                fun_low_complexity(H(:,:,:,k),N_s,N_RFr,N_RFt,structure_flag,QoS,delta_max_eff(s));
            P_temp_lc_fcs(k,1) = norm(F_RF_lc_fcs*F_BB_lc_fcs,'fro')^2;
            
%             [~,~,F_BB_it_pcs,F_RF_it_pcs,~,~,~] = ...
%                 fun_iterative(H(:,:,:,k),N_s,N_RFr,N_RFt,structure_flag-1,QoS,delta_max_eff(s),weight);
%             P_temp_it_pcs(k,1) = norm(F_RF_it_pcs*F_BB_it_pcs,'fro')^2;
%             
%             [~,F_BB_lc_pcs,F_RF_lc_pcs,~,~,~] =...
%                 fun_low_complexity(H(:,:,:,k),N_s,N_RFr,N_RFt,structure_flag-1,QoS,delta_max_eff(s));
%             P_temp_lc_pcs(k,1) = norm(F_RF_lc_pcs*F_BB_lc_pcs,'fro')^2;

        end
        P_it_fcs_mu(r,s) = sum(P_temp_it_fcs)/N_it;
        P_lc_fcs_mu(r,s) = sum(P_temp_lc_fcs)/N_it;
        P_it_pcs_mu(r,s) = sum(P_temp_it_pcs)/N_it;
        P_lc_pcs_mu(r,s) = sum(P_temp_lc_pcs)/N_it;

        % save('P_it_fcs_mu','P_it_fcs_mu')
        % save('P_lc_fcs_mu','P_lc_fcs_mu')
        % save('P_it_pcs_mu','P_it_pcs_mu')
        % save('P_lc_pcs_mu','P_lc_pcs_mu')

    end
end

%% ======================  Non-Robust Methods  ============================
disp('Non-Robust Methods: ')

P_one = zeros(length(QoS_range),1);
P_dft = zeros(length(QoS_range),1);
P_arab = zeros(length(QoS_range),1);

parfor r = 1 : num_QoS
    QoS = QoS_range(r);
    disp('QoS:')
    disp(QoS)
    P_temp_one = zeros(N_it,1);
    P_temp_dft = zeros(N_it,1);
    P_temp_arab = zeros(N_it,1);
    rho = QoS*ones(N_s,1);
    for k = 1:N_it
        
        [F_RF_one, F_BB_one, W_RF_one, W_BB_one] = non_robust_one(H,N_s,N_RFr,N_RFt,QoS);
        [F_RF_dft, F_BB_dft, W_RF_dft, W_BB_dft] = non_robust_dft(H,N_s,N_RFr,N_RFt,QoS);
        P_temp_one(k,1) = norm(F_RF_one*F_BB_one,'fro')^2;
        P_temp_dft(k,1) = norm(F_RF_dft*F_BB_dft,'fro')^2;

        % [P_temp_one(k,1),P_temp_dft(k,1)] = non_robust_art(H(:,:,:,k),N_s,N_RFr,N_RFt,QoS);
        [F_RF,F_BB_arab,W_mu,W_BB] = arab(H(:,:,:,k),N_RFt,N_RFr,N_s,rho);
        F_BB = zeros(N_RFt,U*N_s);
        for u = 1:U
            F_BB(:,(u-1)*N_s+1:u*N_s) = F_BB_arab(:,:,u);
        end
        P_temp_arab(k,1) = norm(F_RF*F_BB,'fro')^2;
    end
    P_one(r,1) = sum(P_temp_one)/N_it;
    P_dft(r,1) = sum(P_temp_dft)/N_it;
    P_arab(r,1) = sum(P_temp_arab)/N_it;
    
    % save('P_one','P_one')
    % save('P_dft','P_dft')
    % save('P_arab','P_arab')
end


hold on
grid on
xlabel('$\rho$','fontsize',14, 'interpreter', 'latex')
ylabel('Transmit Power (dBW)','fontsize',14, 'FontName','Times New Roman')

plot(QoS_range,10*log10(P_dft),'r+-','linewidth',2,'markersize',8)
plot(QoS_range,10*log10(P_one),'*-','Color',[0.93,0.69,0.13],'linewidth',2,'markersize',10)
plot(QoS_range,10*log10(P_arab),'mp-','linewidth',2,'markersize',8)
plot(QoS_range,10*log10(P_lc_fcs_mu(:,3)),'gsquare--','linewidth',2,'markersize',8)
plot(QoS_range,10*log10(P_it_fcs_mu(:,3)),'bo--','linewidth',2,'markersize',8)
plot(QoS_range,10*log10(P_lc_fcs_mu(:,2)),'gsquare-','linewidth',2,'markersize',8)
plot(QoS_range,10*log10(P_it_fcs_mu(:,2)),'bo-','linewidth',2,'markersize',8)
plot(QoS_range,10*log10(P_lc_fcs_mu(:,1)),'g-','linewidth',2,'markersize',8)
plot(QoS_range,10*log10(P_it_fcs_mu(:,1)),'b-','linewidth',2,'markersize',8)


legend('Non-robust [5]','Non-robust [6]','ARAB','LC, $\epsilon_{\rm eff} = 1$','It, $\epsilon_{\rm eff} = 1$',...
    'LC, $\epsilon_{\rm eff} = 0.5$','It, $\epsilon_{\rm eff}$ = 0.5',...
    'LC, $\epsilon_{\rm eff} = 0$','It, $\epsilon_{\rm eff} = 0$',...
    'fontsize',10, 'interpreter', 'latex', 'NumColumns', 2)