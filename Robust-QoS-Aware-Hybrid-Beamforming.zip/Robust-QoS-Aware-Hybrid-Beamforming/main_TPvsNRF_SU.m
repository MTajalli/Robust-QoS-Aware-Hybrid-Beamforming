%% =======================  Description  ==================================
% This files prints the plot of Fig. 6 in the paper for transmit power of 
% single-user systems with respect to the number of RF chains for our HB
% methods (Iterative and Low-complexity) in fully-connected and partially-
% connected structures, fully-digital and robust SDP-based method, and 
% state-of-the-art non-robust HB method in [7].


%% ==========================System Parameters==============================
clear
clc
cvx_quiet true

N_t = 20; % input('Number of Horizontal Transmitter Antennas: ');
N_r = 8; % input('Number of Horizontal Receiver Antennas: ');
N_cl = 3; % input('Number of Channel Clusters: ');
N_s = 2; % input('Number of Data Streams: ');
% N_RFt = input('Number of RF Chains at Transmitter: ');
% N_RFr = input('Number of RF Chains at Receiver: ');
U = 1; % input('Number of Users: ');

QoS = 0.2; % MSE target per stream

structure_flag = 1; % Structure Flag (FCS = 1 and PCS =0)

N_it = 1;

delta_max_range = [0, 1.034];
delta_max_eff_fcs = [0, 0.258];
% delta_max_eff_pcs = [0, 0.202];

N_RF_range = 2 : 8;
num_RF = length(N_RF_range);

num_delta = length(delta_max_range);


P_sdp = zeros(length(N_RF_range),length(delta_max_range));
P_it_fcs_su = zeros(length(N_RF_range),length(delta_max_range));
P_lc_fcs_su = zeros(length(N_RF_range),length(delta_max_range));
P_it_pcs_su = zeros(length(N_RF_range),length(delta_max_range));
P_lc_pcs_su = zeros(length(N_RF_range),length(delta_max_range));
P_opt_su = zeros(length(N_RF_range),length(delta_max_range));
P_jsac_su = zeros(length(N_RF_range),length(delta_max_range));


N_max = 1000;

% H = zeros(N_r, N_t, U, N_max);
% for u = 1:U
%     for k = 1:N_max
%         [H(:,:,u,k), ~] = channel_generation_ULA(N_t, N_r, N_cl);
%     end
% end

load('H_sdp')
H = H_sdp;

weight = 0.1;
parpool('local', num_RF)

for s = 1 : num_delta
    
    delta_max = delta_max_range(s);
    disp('delta_max:')
    disp(delta_max)

    parfor r = 1 : num_RF
        
        N_RF = N_RF_range(r);
        N_RFt = N_RF;
        N_RFr = N_RF;
        disp('Number of RF Chains:')
        disp(N_RF)

        P_temp_sdp = zeros(N_it,1);
        P_temp_it_fcs = zeros(N_it,1);
        P_temp_lc_fcs = zeros(N_it,1);
        P_temp_it_pcs = zeros(N_it,1);
        P_temp_lc_pcs = zeros(N_it,1);
        P_temp_opt = zeros(N_it,1);
        P_temp_jsac = zeros(N_it,1);

        inf_sdp = 0;
        inf_it = 0;
        inf_lc = 0;

        for k = 1:N_it
            disp('Channel Number')
            disp(k)

            while true
                [~, ~, P_new, Flag] = fun_sdp(H(:,:,:,inf_sdp + k), N_s, QoS, delta_max);
                if Flag == 0
                    disp('SDP is Infeasible')
                    [~, ~, P_new, ~] = fun_sdp(H_sdp,N_s,QoS,delta_max);
                    P_temp_sdp(k,1) = P_new;
                    inf_sdp = inf_sdp + 1;
                else
                    P_temp_sdp(k,1) = P_new;
                    break
                end
            end
            [~, ~, F_BB_it_fcs, F_RF_it_fcs, ~, ~, ~] = ...
                fun_iterative(H(:,:,:,inf_sdp+k),N_s,N_RFr,N_RFt,structure_flag,QoS,delta_max_eff_fcs(s),weight);
            P_temp_it_fcs(k,1) = norm(F_RF_it_fcs*F_BB_it_fcs,'fro')^2;

            [~,F_BB_lc_fcs,F_RF_lc_fcs,W_BB_lc_fcs,W_RF_lc_fcs,N_ds_lc_fcs] =...
                fun_low_complexity(H(:,:,:,inf_sdp+k),N_s,N_RFr,N_RFt,structure_flag,QoS,delta_max_eff_fcs(s));
            P_temp_lc_fcs(k,1) = norm(F_RF_lc_fcs*F_BB_lc_fcs,'fro')^2;
            
            % while true
            %     [~,~,F_BB_it_pcs,F_RF_it_pcs,W_BB_it_pcs,W_RF_it_pcs,N_ds_it_pcs] = ...
            %         fun_iterative(H(:,:,:,inf_it+inf_sdp+k),N_s,N_RFr,N_RFt,structure_flag-1,QoS,delta_max_eff_pcs(s),weight);
            % 
            %     if N_ds_it_pcs == U*N_s
            %         P_temp_it_pcs(k,1) = norm(F_RF_it_pcs*F_BB_it_pcs,'fro')^2;
            %         break
            %     else
            %         disp('AR~= 1 in Iterative PCS ')
            %         inf_it = inf_it + 1;
            %         [~, ~, F_BB_it_pcs, F_RF_it_pcs, ~, ~, ~] = ...
            %             fun_iterative(H_sdp,N_s,N_RFr,N_RFt,structure_flag-1,QoS,delta_max_eff_pcs(s),weight);
            %         P_temp_it_pcs(k,1) = norm(F_RF_it_pcs*F_BB_it_pcs,'fro')^2;
            %     end
            % end
            
            % while true
            %     [~,F_BB_lc_pcs,F_RF_lc_pcs,W_BB_lc_pcs,W_RF_lc_pcs,N_ds_lc_pcs] =...
            %         fun_low_complexity(H(:,:,:,inf_lc+inf_sdp+k),N_s,N_RFr,N_RFt,structure_flag-1,QoS,delta_max_eff_pcs(s));
            %     if N_ds_lc_pcs == U*N_s
            %         P_temp_lc_pcs(k,1) = norm(F_RF_lc_pcs*F_BB_lc_pcs,'fro')^2;
            %         break
            %     else
            %         disp('AR~= 1 in Low-Complexity PCS ')
            %         [~, F_BB_lc_pcs, F_RF_lc_pcs, ~, ~, ~] =...
            %         fun_low_complexity(H_sdp,N_s,N_RFr,N_RFt,structure_flag-1,QoS,delta_max_eff_pcs(s));
            %         P_temp_lc_pcs(k,1) = norm(F_RF_lc_pcs*F_BB_lc_pcs,'fro')^2;
            %         inf_lc = inf_lc + 1;
            %     end
            % end
            [P_opt,F_jsac,W_jsac] = jsac_joint(H_sdp,N_s,N_RFt,QoS);
            P_temp_opt(k,1) = P_opt;
            P_temp_jsac(k,1) = norm(F_jsac,'fro')^2;
            
        end
        P_sdp(r,s) = sum(P_temp_sdp)/N_it;
        P_it_fcs_su(r,s) = sum(P_temp_it_fcs)/N_it;
        P_lc_fcs_su(r,s) = sum(P_temp_lc_fcs)/N_it;
        % P_it_pcs_su(r,s) = sum(P_temp_it_pcs)/N_it;
        % P_lc_pcs_su(r,s) = sum(P_temp_lc_pcs)/N_it;
        P_opt_su(r,s) = sum(P_temp_opt)/N_it;
        P_jsac_su(r,s) = sum(P_temp_jsac)/N_it;
        
%         save('P_sdp_non','P_sdp')
%         save('P_lc_fcs_non','P_lc_fcs_su')
%         save('P_it_fcs_non','P_it_fcs_su')
%         save('P_lc_pcs_non','P_lc_pcs_su')
%         save('P_it_pcs_non','P_it_pcs_su')
%         save('P_opt','P_opt_su')
%         save('P_jsac','P_jsac_su')
        
    end
end

figure
hold on
grid on

plot (N_RF_range,10*log10(P_sdp(:,2)),'r--+','markersize',8,'linewidth',2)
% plot (N_RF_range,10*log10(P_lc_pcs_su(:,2)),'g--^','markersize',8,'linewidth',2)
% plot (N_RF_range,10*log10(P_it_pcs_su(:,2)),'b--v','markersize',8,'linewidth',2)
plot (N_RF_range,10*log10(P_lc_fcs_su(:,2)),'g--square','markersize',8,'linewidth',2)
plot (N_RF_range,10*log10(P_it_fcs_su(:,2)),'b--o','markersize',8,'linewidth',2)



% plot (N_RF_range,10*log10(P_it_pcs_su(:,1)),'b-v','markersize',8,'linewidth',2)
% plot (N_RF_range,10*log10(P_lc_pcs_su(:,1)),'g-^','markersize',8,'linewidth',2)

plot (N_RF_range,smooth(smooth(10*log10(P_jsac_su(:,1)))),'m-h','markersize',8,'linewidth',2)

plot (N_RF_range,10*log10(P_sdp(:,1)),'r-+','markersize',8,'linewidth',2)
plot (N_RF_range,10*log10(P_it_fcs_su(:,1)),'b-o','markersize',8,'linewidth',2)
plot (N_RF_range,10*log10(P_lc_fcs_su(:,1)),'g-square','markersize',8,'linewidth',2)

plot (N_RF_range,10*log10(P_opt_su(:,1)),'k-p','markersize',8,'linewidth',2)


legend('SDP, $\epsilon = 1.03$',...
    'LC, $\epsilon_{\rm eff} = 0.26$','It, $\epsilon_{\rm eff} = 0.26$',...
    'HB, Perfect CSI [7]',...
'SDP, $\epsilon = 0$','It, $\epsilon_{\rm eff} = 0$', 'LC, $\epsilon_{\rm eff} = 0$',...
    'FD, Perfect CSI', 'fontsize',10,'NumColumns',2, 'interpreter', 'latex')
    

xlabel('$N_{\rm RF}$','fontsize',14, 'Interpreter','latex')
ylabel('Transmit Power (dBW)','fontsize',14, 'FontName', 'Times New Roman')