function [F_RFWU, F_BB, W_RF, W_BB] = non_robust_one(H,N_s,N_RFr,N_RFt,QoS)

[N_r,N_t,U] = size(H);
sigma = 1;

W_RFWU = zeros(N_r,N_RFr,U);
for u = 1:U
    [Uu,~,~] = svd(H(:,:,u));
    W_RFWU(:,:,u) = exp(1i*angle(Uu(:,1:N_RFr)));
end
W_blk = zeros(U*N_r,U*N_RFr);
H_blk = zeros(U*N_r,N_t);
for u = 1:U
    W_blk((u-1)*N_r+1:u*N_r,(u-1)*N_RFr+1:u*N_RFr) = W_RFWU(:,:,u);
    H_blk((u-1)*N_r+1:u*N_r,:) = H(:,:,u);
end
H_comp = W_blk'*H_blk;
[~,~,V_comp] = svd(H_comp);
V_comp = V_comp(:,1:N_RFt);
F_RFWU = exp(1i*angle(V_comp));
Heff = zeros(N_RFr,N_RFt,U);
Heff_u = zeros((U-1)*N_RFr,N_RFt,U);
for u=1:U
    Heff(:,:,u) = W_RFWU(:,:,u)'*H(:,:,u)*F_RFWU;
end
V_0 = zeros(N_RFt,N_RFt-(U-1)*N_RFr,U);
F_HBD = zeros(N_RFt,N_s,U);
W_HBD = zeros(N_RFr,N_s,U);
sum_power_wu = 0;
for u = 1:U
    for uu = setdiff(1:U,u)
        Heff_u((uu-1)*N_RFr+1:uu*N_RFr,:,u) = Heff(:,:,uu);
    end
    R_nu = sigma^2*W_RFWU(:,:,u)'*W_RFWU(:,:,u);
    [~,~,V_intu] = svd(Heff_u(:,:,u));
    V_0(:,:,u) = V_intu(:,(U-1)*N_RFr+1:N_RFt);
    [~,S_u,V_u] = svd(sqrtm(inv(R_nu))*Heff(:,:,u)*V_0(:,:,u));
    
    rho = QoS*ones(N_s,1);
    p_hbd = 1./diag(S_u(1:N_s,1:N_s).^2).*(1./rho-1);
    F_HBD(:,:,u) = V_0(:,:,u)*V_u(:,1:N_s)*sqrtm(diag(p_hbd));
    F_AD = F_RFWU*F_HBD(:,:,u);
    sum_power_wu = sum_power_wu + trace(F_AD'*F_AD);

    W_HBD(:,:,u)=inv(Heff(:,:,u)*F_HBD(:,:,u)*F_HBD(:,:,u)'*Heff(:,:,u)'+R_nu)*Heff(:,:,u)*F_HBD(:,:,u);
end
F_BB = zeros(N_RFt,U*N_s);
W_BB = cell(1,U);
W_RF = cell(1,U);
for u = 1:U
    F_BB(:,(u-1)*N_s+1:u*N_s) = F_HBD(:,:,u);
    W_BB{1,u} = W_HBD(:,:,u);
    W_RF{1,u} = W_RFWU(:,:,u);
end
end